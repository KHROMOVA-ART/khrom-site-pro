/**
 * Шрифт подключается через @font-face в index.css (там же лежит и сам файл,
 * вшитый как data URI) — никакой асинхронной загрузки и никакого delayRender.
 * Подробности, почему не loadFont(), — в комментарии в index.css.
 */
export const DURIK_FONT_FAMILY = "DURIK";
