import { AbsoluteFill } from "remotion";

/**
 * Тёмная подложка снизу: субтитры остаются читаемыми
 * на любом кадре, но кадр при этом не выглядит замазанным.
 *
 * Ставится один раз на всю длину ролика.
 */
export const BottomScrim: React.FC = () => (
  <AbsoluteFill
    style={{
      background:
        "linear-gradient(to top, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.38) 18%, rgba(0,0,0,0) 38%)",
    }}
  />
);
