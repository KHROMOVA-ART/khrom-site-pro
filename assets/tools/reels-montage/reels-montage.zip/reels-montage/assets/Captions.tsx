import { Sequence } from "remotion";
import { CaptionBlock, Token } from "./CaptionBlock";

/**
 * Дорожка субтитров. Каждая реплика — отдельный <Sequence> с именем,
 * по которому её видно в таймлайне: Катя двигает блоки руками и ищет
 * нужный по тексту, а не по номеру кадра.
 *
 * Тайминги сняты с расшифровки whisper и сверены с картой громкости
 * (node loudness-map.mjs) — точность ~0,15 с.
 */
const Block: React.FC<{
  name: string;
  from: number;
  durationInFrames: number;
  tokens: Token[];
}> = ({ name, from, durationInFrames, tokens }) => (
  <Sequence
    name={name}
    from={from}
    durationInFrames={durationInFrames}
    layout="none"
  >
    <CaptionBlock tokens={tokens} />
  </Sequence>
);

export const Captions: React.FC = () => {
  return (
    <>
      <Block
        name="01 — первая реплика"
        from={83}
        durationInFrames={30}
        tokens={[
          { text: "Первая" },
          { text: "реплика", highlight: true },
        ]}
      />

      {/*
        На смысловом панче задавай кадры появления вручную (`at`),
        чтобы слова падали ровно на голос, а не через равные промежутки.
      */}
      <Block
        name="02 — панчлайн"
        from={1097}
        durationInFrames={151}
        tokens={[
          { text: "очень", at: 0 },
          { text: "системно", highlight: true, at: 27 },
          { text: "думать.", highlight: true, at: 63 },
        ]}
      />
    </>
  );
};
