import {
  AbsoluteFill,
  Easing,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { DURIK_FONT_FAMILY } from "../fonts";
import { HIGHLIGHT_COLOR } from "./style";

/**
 * Моушн-дизайн врезки — то, чем разбавлена говорящая голова.
 *
 * Врезка занимает весь кадр и глушит видео; речь при этом не прерывается,
 * потому что звук идёт отдельной дорожкой (Voice.tsx). Субтитры продолжают
 * идти поверх врезки — поэтому нижние ~300 px кадра сцены не занимают.
 *
 * Правила, которые тут зашиты:
 *
 * 1. Фон тёмный (INK). Субтитры белые: на кремовом фоне они исчезают.
 * 2. Одна врезка — одна мысль. Не «а ещё сюда влезет».
 * 3. Врезка иллюстрирует ровно то слово, которое звучит в этот момент,
 *    и появляется на нём же, а не «где-то рядом».
 *
 * Ниже — общий каркас (палитра, Scene, Label) и две сцены, которые
 * переезжают из ролика в ролик: список решений и гильош. Сцены под
 * конкретный предмет разговора (лист, коробка, экран, что угодно)
 * пишутся заново — FoldingSheet оставлен как образец, как это делается.
 */

export const INK = "#14110E";
export const PAPER = "#F0EAE0";
export const PAPER_BACK = "#DED3C1";
export const LINE = "#6E6559";

/** Вертикальный центр графики. Ниже ~760 px начинается зона субтитров. */
export const CENTER_Y = 420;

/** Общая обёртка: короткий въезд, чтобы врезка не «прилипала» встык. */
export const Scene: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill style={{ backgroundColor: INK, overflow: "hidden" }}>
      <AbsoluteFill
        style={{
          opacity: interpolate(frame, [0, 5], [0, 1], {
            extrapolateRight: "clamp",
          }),
          scale: interpolate(frame, [0, 14], [1.05, 1], {
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          }),
        }}
      >
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/** Подпись под графикой — мелкая, разрядкой, чтобы не спорила с субтитрами. */
export const Label: React.FC<{
  text: string;
  appearsAt: number;
  top: number;
  color?: string;
}> = ({ text, appearsAt, top, color = LINE }) => {
  const frame = useCurrentFrame();

  return (
    <div
      style={{
        position: "absolute",
        top,
        left: 0,
        right: 0,
        textAlign: "center",
        fontFamily: DURIK_FONT_FAMILY,
        fontSize: 44,
        letterSpacing: 10,
        color,
        opacity: interpolate(frame, [appearsAt, appearsAt + 8], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
        translate: interpolate(
          frame,
          [appearsAt, appearsAt + 14],
          ["0px 12px", "0px 0px"],
          {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          },
        ),
      }}
    >
      {text}
    </div>
  );
};

/* ────────────────────────────────────────────────────────────────────────
   Сцена «список решений» — самая переносимая из всех.

   Показывает не слова из субтитров, а то, о чём они: разложенное на строки
   решение. Когда Катя говорит «это супер оптимизировано, супер дёшево,
   супер продумано», на экране не эти три слова (их и так видно в титрах),
   а техкарта: формат, сгиб, крепёж, бумага — и внизу «решений принято:
   десятки». Это и есть core truth «дизайн — это система решений»,
   показанный, а не названный.

   Пять строк — потолок: шестая заезжает на субтитры.
   ──────────────────────────────────────────────────────────────────────── */

export type SpecRow = {
  key: string;
  value: string;
  /** Кадр появления строки от начала врезки — ставь по голосу. */
  at: number;
};

export const SceneSpec: React.FC<{
  title: string;
  rows: SpecRow[];
  /** Последняя строка красится в персик — это вывод, а не пункт. */
  accentLast?: boolean;
}> = ({ title, rows, accentLast = true }) => {
  const frame = useCurrentFrame();

  return (
    <Scene>
      <div
        style={{
          position: "absolute",
          left: 235,
          right: 235,
          top: 172,
          fontFamily: DURIK_FONT_FAMILY,
        }}
      >
        <div
          style={{
            fontSize: 52,
            letterSpacing: 14,
            color: HIGHLIGHT_COLOR,
            opacity: interpolate(frame, [0, 10], [0, 1], {
              extrapolateRight: "clamp",
            }),
            marginBottom: 40,
          }}
        >
          {title}
        </div>

        {rows.map((row, i) => {
          const appear = interpolate(frame, [row.at, row.at + 9], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          });
          const last = accentLast && i === rows.length - 1;

          return (
            <div
              key={row.key}
              style={{
                display: "flex",
                alignItems: "baseline",
                gap: 24,
                paddingTop: 17,
                paddingBottom: 17,
                borderTop: `1px solid ${LINE}`,
                opacity: appear,
                translate: interpolate(
                  frame,
                  [row.at, row.at + 16],
                  ["-26px 0px", "0px 0px"],
                  {
                    extrapolateLeft: "clamp",
                    extrapolateRight: "clamp",
                    easing: Easing.bezier(0.16, 1, 0.3, 1),
                  },
                ),
              }}
            >
              <span style={{ fontSize: 48, color: PAPER_BACK, letterSpacing: 5 }}>
                {row.key}
              </span>
              <span
                style={{ flex: 1, borderBottom: `1px dotted ${LINE}`, height: 1 }}
              />
              <span
                style={{
                  fontSize: 58,
                  color: last ? HIGHLIGHT_COLOR : PAPER,
                  letterSpacing: 2,
                }}
              >
                {row.value}
              </span>
            </div>
          );
        })}
      </div>
    </Scene>
  );
};

/* ────────────────────────────────────────────────────────────────────────
   Сцена «гильош» — розетка рисует сама себя.

   Годится всюду, где речь про узор, орнамент, защитную сетку, «красоту
   ради красоты», типографику бланков. Красиво само по себе и стоит две
   секунды — ровно столько, сколько нужно, чтобы перебить кадр и вернуться.
   ──────────────────────────────────────────────────────────────────────── */

/** Розетка: r = R + a·cos(k·t). Такие узоры и печатают на бланках. */
export const rosette = (R: number, a: number, k: number, steps = 720) => {
  let d = "";
  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * Math.PI * 2;
    const r = R + a * Math.cos(k * t);
    d += `${i === 0 ? "M" : "L"}${(Math.cos(t) * r).toFixed(2)} ${(
      Math.sin(t) * r
    ).toFixed(2)} `;
  }
  return d + "Z";
};

// len — примерная длина контура: она уходит в strokeDasharray, и точность
// тут не нужна, лишь бы была не меньше настоящей.
const ROSETTES = [
  { d: rosette(330, 52, 12), len: 2500, color: PAPER, at: 0, width: 2.4 },
  { d: rosette(248, 38, 18), len: 2000, color: HIGHLIGHT_COLOR, at: 9, width: 2.6 },
  { d: rosette(168, 26, 9), len: 1250, color: PAPER_BACK, at: 18, width: 2 },
];

export const SceneOrnament: React.FC<{ durationInFrames: number }> = ({
  durationInFrames,
}) => {
  const frame = useCurrentFrame();

  return (
    <Scene>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {/* вращается вся группа целиком: покрути розетки по отдельности —
            и вместо орнамента получится каракуля */}
        <g
          transform={`translate(960 ${CENTER_Y}) rotate(${interpolate(
            frame,
            [0, durationInFrames],
            [0, 9],
          )})`}
        >
          <circle
            r={356}
            fill="none"
            stroke={LINE}
            strokeWidth={1.4}
            opacity={interpolate(frame, [4, 20], [0, 1], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            })}
          />
          {ROSETTES.map((r, i) => (
            <path
              key={i}
              d={r.d}
              fill="none"
              stroke={r.color}
              strokeWidth={r.width}
              strokeDasharray={r.len}
              strokeDashoffset={interpolate(frame, [r.at, r.at + 30], [r.len, 0], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
                easing: Easing.bezier(0.4, 0, 0.2, 1),
              })}
            />
          ))}
        </g>
      </svg>
    </Scene>
  );
};

/* ────────────────────────────────────────────────────────────────────────
   Образец сцены под конкретный предмет разговора.

   Это НЕ универсальный компонент — это пример того, как выглядит сцена,
   написанная под одну реплику. Речь шла про сертификат прививок, который
   складывается пополам и сшивается скобой, — значит, на экране лист,
   который складывается пополам, и скоба, которая в него входит.

   Под другой ролик такую сцену пишут заново. Ориентиры: предмет крупно
   (лист 424×600 в кадре 1920×1080 — это минимум, меньше не читается),
   одно действие, действие заканчивается за 1–2 секунды до конца врезки.
   ──────────────────────────────────────────────────────────────────────── */

export const SHEET_W = 424;
export const SHEET_H = 600; // пропорция А4

const FoldingSheet: React.FC<{
  /** 0 — развёрнутый лист, 1 — книжка. */
  progress: number;
  /** 0 — линия сгиба не нарисована, 1 — нарисована целиком. */
  creaseProgress: number;
}> = ({ progress, creaseProgress }) => {
  const angle = progress * 180;
  const half = SHEET_W / 2;

  return (
    <div
      style={{
        position: "absolute",
        left: 960 - half,
        top: CENTER_Y - SHEET_H / 2,
        width: SHEET_W,
        height: SHEET_H,
        perspective: 1400,
      }}
    >
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: half,
          height: SHEET_H,
          backgroundColor: PAPER,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: half,
          top: 0,
          width: half,
          height: SHEET_H,
          // после 90° видно изнанку — она темнее
          backgroundColor: angle > 90 ? PAPER_BACK : PAPER,
          transformOrigin: "left center",
          transform: `rotateY(${-angle}deg)`,
          boxShadow: progress > 0.02 ? "0 30px 60px rgba(0,0,0,0.55)" : "none",
        }}
      />
      <svg
        width={SHEET_W}
        height={SHEET_H}
        style={{ position: "absolute", left: 0, top: 0 }}
      >
        <line
          x1={half}
          y1={0}
          x2={half}
          y2={SHEET_H}
          stroke={HIGHLIGHT_COLOR}
          strokeWidth={3}
          strokeDasharray={`${SHEET_H}`}
          strokeDashoffset={SHEET_H * (1 - creaseProgress)}
          opacity={1 - progress}
        />
      </svg>
    </div>
  );
};

/** «…идеально складываются пополам» — лист, линия сгиба, сгиб. */
export const SceneFold: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <Scene>
      <FoldingSheet
        creaseProgress={interpolate(frame, [14, 40], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: Easing.bezier(0.4, 0, 0.2, 1),
        })}
        progress={interpolate(frame, [46, 86], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: Easing.bezier(0.6, 0, 0.2, 1),
        })}
      />
    </Scene>
  );
};

/** «…печатать на А4… и в скобу» — размеры, формат, сгиб, скобы. */
export const SceneA4: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const left = 960 - SHEET_W / 2;
  const top = CENTER_Y - SHEET_H / 2;

  const draw = (from: number, to: number, len: number) =>
    len *
    (1 -
      interpolate(frame, [from, to], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
        easing: Easing.bezier(0.4, 0, 0.2, 1),
      }));

  const fold = interpolate(frame, [74, 96], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.6, 0, 0.2, 1),
  });

  return (
    <Scene>
      <FoldingSheet progress={fold} creaseProgress={1} />

      {/* размерные линии — только пока лист развёрнут */}
      <svg
        width={1920}
        height={1080}
        style={{ position: "absolute", inset: 0, opacity: 1 - fold }}
      >
        <line
          x1={left}
          y1={top - 44}
          x2={left + SHEET_W}
          y2={top - 44}
          stroke={LINE}
          strokeWidth={2}
          strokeDasharray={SHEET_W}
          strokeDashoffset={draw(6, 26, SHEET_W)}
        />
        <line
          x1={left + SHEET_W + 44}
          y1={top}
          x2={left + SHEET_W + 44}
          y2={top + SHEET_H}
          stroke={LINE}
          strokeWidth={2}
          strokeDasharray={SHEET_H}
          strokeDashoffset={draw(14, 38, SHEET_H)}
        />
        <text
          x={left + SHEET_W / 2}
          y={top - 64}
          fill={LINE}
          fontSize={40}
          fontFamily={DURIK_FONT_FAMILY}
          textAnchor="middle"
          letterSpacing={4}
          opacity={interpolate(frame, [26, 36], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          })}
        >
          210
        </text>
        <text
          x={left + SHEET_W + 68}
          y={top + SHEET_H / 2}
          fill={LINE}
          fontSize={40}
          fontFamily={DURIK_FONT_FAMILY}
          letterSpacing={4}
          opacity={interpolate(frame, [36, 46], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          })}
        >
          297
        </text>
      </svg>

      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: CENTER_Y - 68,
          textAlign: "center",
          fontFamily: DURIK_FONT_FAMILY,
          fontSize: 130,
          color: HIGHLIGHT_COLOR,
          opacity:
            interpolate(frame, [30, 40], [0, 1], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            }) *
            (1 - fold),
        }}
      >
        А4
      </div>

      {/* скобы вбиваются по сгибу — пружиной, а не линейно */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {[-118, 118].map((dy, i) => {
          const s = spring({
            frame: frame - (98 + i * 7),
            fps,
            config: { damping: 12, mass: 0.5 },
          });
          return (
            <g
              key={dy}
              opacity={s}
              transform={`translate(960 ${CENTER_Y + dy}) scale(${0.6 + s * 0.4})`}
            >
              <rect x={-13} y={-43} width={26} height={86} rx={5} fill={HIGHLIGHT_COLOR} />
            </g>
          );
        })}
      </svg>

      <Label
        text="СКОБА"
        appearsAt={112}
        top={CENTER_Y + SHEET_H / 2 + 46}
        color={HIGHLIGHT_COLOR}
      />
    </Scene>
  );
};
