import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";
import { DURIK_FONT_FAMILY } from "../fonts";
import {
  CAPTIONS_BOTTOM_INSET,
  FONT_SIZE,
  HIGHLIGHT_COLOR,
  TEXT_COLOR,
  WORD_STAGGER,
} from "./style";

export type Token = {
  text: string;
  /** true — слово красится в оранжевый персик. */
  highlight?: boolean;
  /**
   * На каком кадре от начала блока появляется слово.
   * Если не задано — слова выходят по очереди через WORD_STAGGER.
   */
  at?: number;
};

const Word: React.FC<{
  text: string;
  highlight: boolean;
  appearsAt: number;
}> = ({ text, highlight, appearsAt }) => {
  const frame = useCurrentFrame();

  return (
    <span
      style={{
        display: "inline-block",
        color: highlight ? HIGHLIGHT_COLOR : TEXT_COLOR,
        opacity: interpolate(frame, [appearsAt, appearsAt + 4], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
        translate: interpolate(
          frame,
          [appearsAt, appearsAt + 7],
          ["0px 14px", "0px 0px"],
          {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          },
        ),
      }}
    >
      {text}
    </span>
  );
};

/**
 * Строка субтитра: слова появляются поэтапно,
 * ключевые — оранжевым персиком.
 */
export const CaptionBlock: React.FC<{ tokens: Token[] }> = ({ tokens }) => {
  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-end",
        alignItems: "center",
        paddingLeft: 160,
        paddingRight: 160,
        paddingBottom: CAPTIONS_BOTTOM_INSET,
      }}
    >
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          columnGap: FONT_SIZE * 0.26,
          rowGap: FONT_SIZE * 0.14,
          fontFamily: DURIK_FONT_FAMILY,
          fontSize: FONT_SIZE,
          lineHeight: 1.1,
          textAlign: "center",
          textShadow: "0 6px 30px rgba(0,0,0,0.75)",
        }}
      >
        {tokens.map((token, i) => (
          <Word
            key={i}
            text={token.text}
            highlight={token.highlight === true}
            appearsAt={token.at ?? i * WORD_STAGGER}
          />
        ))}
      </div>
    </AbsoluteFill>
  );
};
