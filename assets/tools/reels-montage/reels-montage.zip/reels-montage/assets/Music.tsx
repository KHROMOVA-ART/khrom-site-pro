import { Audio } from "@remotion/media";
import { Sequence, staticFile } from "remotion";
import { CHUNKS, chunkStarts } from "./Voice";

/**
 * Музыкальная подложка с автоматическим приглушением под речь.
 *
 * Главное здесь — не музыка, а то, что громкость считается из тех же
 * CHUNKS, по которым собран голос. Не надо расставлять точки громкости
 * руками и переставлять их после каждого сдвига блока: подвинула речь —
 * приглушение поехало за ней.
 *
 * Уровни (в долях от громкости файла):
 *
 *   под речью   0.18   музыка слышна, но не спорит со словами
 *   в паузах    0.55   пауза наполняется, а не проваливается в тишину
 *   на входе    0.55   первые полсекунды до первого слова
 *   на выходе   fade   последние 30 кадров
 *
 * Приём из ролика Multiply Sound (tonal sound effects): подложка — это
 * не «песня фоном», а дрон в тональности плюс редкие тональные удары
 * на смысловых стыках. Дрон кладётся сюда как `src`, удары — отдельными
 * <Hit> на нужных кадрах. Когда музыка звучит песней, она перетягивает
 * внимание с речи; когда дроном — держит воздух.
 *
 * ФАЙЛЫ КЛАДУТСЯ В public/music/. Их надо принести: сгенерировать музыку
 * нельзя, а тащить что попало из интернета — это чужие права на Катином
 * канале. Пока файла нет, компонент просто не ставится в Reel.tsx.
 */

/** Громкость подложки, когда звучит речь. */
const UNDER_VOICE = 0.18;
/** Громкость в паузах между кусками речи. */
const IN_GAPS = 0.55;
/** За сколько кадров музыка ныряет и всплывает. */
const RAMP = 8;

/**
 * Считает громкость музыки на кадре f (относительно начала дорожки речи).
 * Ныряет заранее — на RAMP кадров до первого слова, иначе музыка
 * «догоняет» речь и первое слово тонет.
 */
export const duck = (f: number): number => {
  for (let i = 0; i < CHUNKS.length; i++) {
    const start = chunkStarts[i];
    const end = start + CHUNKS[i].durationInFrames;
    if (f >= start - RAMP && f <= end + RAMP) {
      // внутри куска или на его склонах
      if (f < start) {
        return IN_GAPS + ((UNDER_VOICE - IN_GAPS) * (f - (start - RAMP))) / RAMP;
      }
      if (f > end) {
        return UNDER_VOICE + ((IN_GAPS - UNDER_VOICE) * (f - end)) / RAMP;
      }
      return UNDER_VOICE;
    }
  }
  return IN_GAPS;
};

export const Music: React.FC<{
  /** Файл в public/music/, например "music/drone-am.mp3". */
  src: string;
  /** Где начинается дорожка речи на таймлайне. Обычно 0. */
  voiceFrom?: number;
  /** Общая длина ролика в кадрах. */
  durationInFrames: number;
  /** Общий множитель: подогнать конкретный трек под остальные. */
  gain?: number;
  /** С какого кадра файла играть. */
  trimBefore?: number;
}> = ({ src, voiceFrom = 0, durationInFrames, gain = 1, trimBefore = 0 }) => (
  <Sequence
    name="Музыка — подложка"
    from={0}
    durationInFrames={durationInFrames}
    layout="none"
  >
    <Audio
      src={staticFile(src)}
      trimBefore={trimBefore}
      volume={(f) => {
        const fade = Math.min(
          1,
          f / 20,
          (durationInFrames - f) / 30, // хвост уводится в тишину
        );
        return Math.max(0, duck(f - voiceFrom) * gain * fade);
      }}
    />
  </Sequence>
);

/**
 * Тональный удар на смысловом стыке: перед выводом, на переходе к врезке,
 * на панче. Один-два за ролик, не больше — иначе это уже трейлер, а не
 * разговор.
 *
 * Файл должен быть в той же тональности, что и подложка: разнобой по
 * тональности слышно даже тем, кто не знает, что такое тональность.
 */
export const Hit: React.FC<{
  src: string;
  /** Кадр таймлайна, на котором бьёт. */
  at: number;
  durationInFrames?: number;
  gain?: number;
}> = ({ src, at, durationInFrames = 90, gain = 0.5 }) => (
  <Sequence
    name={`Удар — кадр ${at}`}
    from={at}
    durationInFrames={durationInFrames}
    layout="none"
  >
    <Audio
      src={staticFile(src)}
      volume={(f) =>
        gain * Math.min(1, (durationInFrames - f) / 20)
      }
    />
  </Sequence>
);
