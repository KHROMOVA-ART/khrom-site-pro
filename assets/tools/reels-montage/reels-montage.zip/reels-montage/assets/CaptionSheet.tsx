import { AbsoluteFill, useCurrentFrame } from "remotion";
import { DURIK_FONT_FAMILY } from "../fonts";
import { HIGHLIGHT_COLOR } from "./style";

/**
 * Субтитры режима «архив» (см. SKILL.md, раздел «Режим Б»).
 *
 * Отличий от CaptionBlock три, и все три принципиальные:
 *
 *   1. текст КОПИТСЯ. Строка, которая появилась, никуда не уходит до конца
 *      фразы: к ней снизу дописывается следующая. Зритель видит фразу
 *      целиком, а не последние три слова;
 *   2. строка ВЫКЛЮЧЕНА ПО ФОРМАТУ (justify): слова разгоняются по всей
 *      ширине колонки. Два слова в строке — они у противоположных краёв,
 *      одно — прижато влево. Это и есть весь приём: не шрифт, а разрядка;
 *   3. слова появляются МГНОВЕННО, без fade и без подъезда. Проявление
 *      смазывает попадание в долю, а здесь всё держится на попадании.
 *
 * Текст чёрный и стоит вверху кадра — под него отдаётся верхняя треть,
 * а не нижняя полоса. Подложки нет: читаемость обеспечивает выцветший
 * грейд из Archive.tsx, а не затемнение.
 */

export type SheetWord = {
  text: string;
  /** Кадр появления, от начала блока. Считается по word-таймкодам. */
  at: number;
  /** true — слово красится в оранжевый персик. */
  highlight?: boolean;
};

/** Одна строка. Больше трёх слов в строку не ставь — разрядка исчезнет. */
export type SheetLine = SheetWord[];

export const CaptionSheet: React.FC<{
  lines: SheetLine[];
  /** Кегль в долях ШИРИНЫ кадра. Считается от ширины: строка тянется по ней. */
  sizeRatio?: number;
  /** Отступ колонки от левого и правого края, в долях ширины. */
  sideRatio?: number;
  /** Отступ первой строки от верха кадра, в долях высоты. */
  topRatio?: number;
  color?: string;
  width?: number;
  height?: number;
}> = ({
  lines,
  sizeRatio = 0.09,
  sideRatio = 0.055,
  topRatio = 0.06,
  color = "#0B0B0B",
  width = 1080,
  height = 1920,
}) => {
  const frame = useCurrentFrame();
  const fontSize = Math.round(width * sizeRatio);

  return (
    <AbsoluteFill
      style={{
        paddingLeft: width * sideRatio,
        paddingRight: width * sideRatio,
        paddingTop: height * topRatio,
        fontFamily: DURIK_FONT_FAMILY,
        fontSize,
        lineHeight: 1.05,
      }}
    >
      {lines.map((line, li) => {
        const visible = line.filter((w) => frame >= w.at);
        // Строка, в которой ещё ничего не прозвучало, не занимает место:
        // иначе следующая фраза приезжает уже сдвинутой вниз.
        if (visible.length === 0) return null;

        return (
          <div
            key={li}
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            {visible.map((word, wi) => (
              <span
                key={wi}
                style={{ color: word.highlight ? HIGHLIGHT_COLOR : color }}
              >
                {word.text}
              </span>
            ))}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
