import { Audio } from "@remotion/media";
import { Sequence, staticFile } from "remotion";

/**
 * Звук ролика — отдельной дорожкой от картинки.
 *
 * Это ключевая вещь во всей раскладке. Пока звук приезжает вместе с
 * видеоклипом, картинку резать нельзя: любая врезка рвёт речь. Как только
 * речь живёт своей дорожкой, а все клипы немые (`Clip` по умолчанию muted),
 * поверх можно ставить что угодно и где угодно — b-roll, моушн-врезку,
 * другой дубль, — а голос идёт непрерывно.
 *
 * Дорожка собрана кусками: кусок = отрезок исходника между двумя паузами.
 * Границы снимаются с карты громкости, а не с расшифровки: whisper к концу
 * файла уезжает по времени на секунду и больше, а тишина не врёт.
 *
 * Паузы и междометия вырезаются всегда, во всех режимах (SKILL.md,
 * раздел 3). Куски не набиваются руками — их печатает скрипт:
 *
 *   node <skill>/scripts/tighten-speech.mjs <проект> part1
 *
 * GAP — сколько кадров тишины оставить на шве. 3 по умолчанию, 4 если
 * на слух речь «глотает». Без зазора совсем она звучит задыхающейся,
 * больше пяти — пауза возвращается.
 */

export const GAP = 3;

export type Chunk = {
  /** Имя блока на таймлайне — по нему Катя ищет кусок в студии. */
  name: string;
  /** Первый кадр исходника. */
  trimBefore: number;
  /** Сколько кадров исходника берём. */
  durationInFrames: number;
};

/** Отрезки речи между вырезанными паузами. Печатает tighten-speech.mjs. */
export const CHUNKS: Chunk[] = [
  { name: "A — первая фраза", trimBefore: 0, durationInFrames: 294 },
  { name: "B — вторая фраза", trimBefore: 316, durationInFrames: 80 },
];

/** Кадр, на котором начинается i-й кусок (относительно начала дорожки). */
export const chunkStarts = (() => {
  const out: number[] = [];
  let at = 0;
  for (const c of CHUNKS) {
    out.push(at);
    at += c.durationInFrames + GAP;
  }
  return out;
})();

/**
 * Общая длина речи вместе с зазорами.
 * От неё считается длительность всей композиции.
 */
export const VOICE_LENGTH =
  chunkStarts[chunkStarts.length - 1] +
  CHUNKS[CHUNKS.length - 1].durationInFrames;

export const Voice: React.FC<{
  /** Файл с озвучкой — тот же mp4, из которого берётся лицо. */
  src: string;
  /** С какого кадра композиции начинается речь. Обычно 0. */
  from?: number;
}> = ({ src, from = 0 }) => (
  <>
    {CHUNKS.map((chunk, i) => (
      <Sequence
        key={chunk.name}
        name={`Звук ${chunk.name}`}
        from={from + chunkStarts[i]}
        durationInFrames={chunk.durationInFrames}
        layout="none"
      >
        <Audio
          src={staticFile(src)}
          trimBefore={chunk.trimBefore}
          trimAfter={chunk.trimBefore + chunk.durationInFrames}
          // короткие фейды по краям: без них на стыке щёлкает
          volume={(f) =>
            Math.min(1, f / 2, (chunk.durationInFrames - f) / 2)
          }
        />
      </Sequence>
    ))}
  </>
);
