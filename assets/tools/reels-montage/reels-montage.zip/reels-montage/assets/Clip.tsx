import { Video } from "@remotion/media";
import { Easing, interpolate, staticFile, useCurrentFrame } from "remotion";

/**
 * Один клип на таймлайне: исходник 1920×1080 на весь кадр
 * с медленным наездом (punch-in).
 *
 * Клипы по умолчанию немые: речь идёт отдельной дорожкой (Voice.tsx),
 * поэтому картинку можно резать где угодно — голос от этого не рвётся.
 *
 * Где стоит клип и сколько длится — задаёт родительский <Sequence>
 * в Reel.tsx. Здесь только `src` (какой файл) и `trimBefore`
 * (с какого кадра исходника играть).
 */
export const Clip: React.FC<{
  name: string;
  src: string;
  trimBefore: number;
  /** Длина клипа в кадрах — чтобы наезд шёл ровно до конца блока. */
  durationInFrames: number;
  /** Стартовое увеличение. 1 = как в исходнике. */
  zoomFrom?: number;
  /** Увеличение к концу клипа. */
  zoomTo?: number;
  /** Скорость. 1 — как в исходнике, 0.35 — замедление почти втрое. */
  playbackRate?: number;
  muted?: boolean;
}> = ({
  name,
  src,
  trimBefore,
  durationInFrames,
  zoomFrom = 1,
  zoomTo = 1.06,
  playbackRate = 1,
  muted = true,
}) => {
  const frame = useCurrentFrame();

  return (
    <Video
      name={name}
      src={staticFile(src)}
      trimBefore={trimBefore}
      playbackRate={playbackRate}
      muted={muted}
      objectFit="cover"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        scale: interpolate(frame, [0, durationInFrames], [zoomFrom, zoomTo], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: Easing.bezier(0.33, 0, 0.67, 1),
        }),
      }}
    />
  );
};
