import { AbsoluteFill, interpolate, staticFile, useCurrentFrame } from "remotion";

/**
 * Фактуры поверх кадра: зерно, бумага, виньетка.
 *
 * Зачем: голая цифровая картинка с телефона выглядит как видеозвонок.
 * Зерно и бумага дают ей вес и делают монтаж похожим на что-то напечатанное,
 * а не отснятое. Это же связывает живые кадры с моушн-врезками — там бумага
 * и так лежит в основе.
 *
 * Плитки печёт `scripts/make-textures.sh` в `public/tex/`. Считать шум
 * в SVG на каждом кадре нельзя: рендер раздувается в разы.
 *
 * Дозировка — главное. Фактура работает, пока её не замечаешь:
 * заметил зерно — значит переборщил. Рабочие значения стоят в умолчаниях,
 * поднимать их выше 0.14 нет причин.
 *
 * Порядок слоёв в кадре: видео → Paper → Grain → Vignette → затемнение → титры.
 */

/**
 * Плёночное зерно. Плитка 512×512 повторяется и раз в несколько кадров
 * прыгает на новое место — глаз читает это как живую плёнку.
 * Двигать каждый кадр не надо: получится кипящая каша.
 */
export const Grain: React.FC<{
  opacity?: number;
  /** Через сколько кадров зерно перескакивает. 2–4 — живо, 1 — кипит. */
  every?: number;
}> = ({ opacity = 0.09, every = 3 }) => {
  const frame = useCurrentFrame();
  const step = Math.floor(frame / every);
  // псевдослучайный, но детерминированный сдвиг: рендер должен быть
  // повторяемым, поэтому никакого Math.random()
  const x = (step * 137) % 512;
  const y = (step * 251) % 512;

  return (
    <AbsoluteFill
      style={{
        backgroundImage: `url(${staticFile("tex/grain.png")})`,
        backgroundRepeat: "repeat",
        backgroundPosition: `${x}px ${y}px`,
        mixBlendMode: "overlay",
        opacity,
        pointerEvents: "none",
      }}
    />
  );
};

/**
 * Бумага: волокно и неровность листа. Не повторяется плиткой, а растягивается
 * на кадр — крупная облачность при повторе выдала бы сетку.
 */
export const Paper: React.FC<{ opacity?: number }> = ({ opacity = 0.28 }) => (
  <AbsoluteFill
    style={{
      backgroundImage: `url(${staticFile("tex/paper.png")})`,
      backgroundSize: "cover",
      backgroundPosition: "center",
      mixBlendMode: "overlay",
      opacity,
      pointerEvents: "none",
    }}
  />
);

/**
 * Виньетка. Гасит углы и сама собой ведёт взгляд в центр — на лицо
 * или на графику. На светлых кадрах с окном в кадре без неё не обойтись.
 */
export const Vignette: React.FC<{ strength?: number }> = ({
  strength = 0.42,
}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse 74% 68% at 50% 46%, rgba(0,0,0,0) 40%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: "none",
    }}
  />
);

/**
 * Все три слоя разом — то, что обычно и нужно. Ставится одним
 * <Sequence> на всю длину ролика, поверх видео и под титрами.
 */
export const Texture: React.FC<{
  grain?: number;
  paper?: number;
  vignette?: number;
}> = ({ grain = 0.09, paper = 0.28, vignette = 0.42 }) => (
  <>
    <Paper opacity={paper} />
    <Grain opacity={grain} />
    <Vignette strength={vignette} />
  </>
);

/**
 * Засветка на склейке: короткая вспышка тёплого света.
 * Ставится на стык между кадрами, длина 4–7 кадров, больше — уже эффект
 * ради эффекта. Использовать редко: одна-две за ролик.
 */
export const Flash: React.FC<{ durationInFrames?: number }> = ({
  durationInFrames = 6,
}) => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#FFE9D6",
        mixBlendMode: "screen",
        opacity: interpolate(
          frame,
          [0, durationInFrames * 0.3, durationInFrames],
          [0, 0.5, 0],
          { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
        ),
        pointerEvents: "none",
      }}
    />
  );
};
