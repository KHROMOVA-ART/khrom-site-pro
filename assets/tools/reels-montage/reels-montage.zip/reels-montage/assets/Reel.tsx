import { AbsoluteFill, Composition, Sequence } from "remotion";
import "../fonts";
import { Captions } from "./Captions";
import { Clip } from "./Clip";
import { SceneOrnament, SceneSpec } from "./Motion";
import { Music } from "./Music";
import { BottomScrim } from "./Scrim";
import { Texture } from "./Texture";
import { Voice, VOICE_LENGTH } from "./Voice";

const FPS = 30;

/**
 * Длительность ролика = длина речи, и ничего сверх.
 * Ни заставки на входе, ни карточки на выходе: ролик начинается с
 * первого слова и заканчивается на последнем.
 */
const DURATION_IN_FRAMES = VOICE_LENGTH;

export const ReelComposition = () => {
  return (
    <Composition
      id="Reel-ИМЯ"
      component={Reel}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={1920}
      height={1080}
    />
  );
};

/**
 * Раскладка ролика — держи эту таблицу в актуальном виде,
 * по ней Катя понимает, что где лежит:
 *
 *    0 –  160  лицо
 *  160 –  222  вставка: b-roll
 *  222 –  510  лицо
 *  510 –  621  моушн-врезка: предмет разговора
 *  621 –  785  лицо
 *  785 –  971  моушн-врезка: список решений
 *  971 – 1036  моушн-врезка: гильош
 * 1036 – …     лицо: панч
 *
 * Звук идёт отдельной дорожкой (Voice.tsx) — поэтому картинку можно
 * резать где угодно, речь от этого не рвётся, а все клипы немые.
 *
 * Каждый <Sequence> — блок на таймлайне Studio:
 * тянешь за середину — двигаешь, тянешь за край — меняешь длину.
 * `trimBefore` — с какого кадра исходника играть.
 *
 * Видеоблоки идут встык, без дырок: между кусками речи зазор есть,
 * а между кусками картинки — нет, иначе на стыке мелькнёт чёрный кадр.
 */
export const Reel: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      {/* ── картинка ─────────────────────────────────────────────── */}

      <Sequence name="Лицо 1" from={0} durationInFrames={160}>
        <Clip
          name="Лицо 1"
          src="part1.mp4"
          trimBefore={0}
          durationInFrames={160}
          zoomTo={1.05}
        />
      </Sequence>

      <Sequence name="Вставка — b-roll" from={160} durationInFrames={62}>
        <Clip
          name="Вставка — b-roll"
          src="part2.mp4"
          trimBefore={1200}
          durationInFrames={62}
          zoomFrom={1.02}
          zoomTo={1.1}
        />
      </Sequence>

      <Sequence name="Лицо 2" from={222} durationInFrames={288}>
        <Clip
          name="Лицо 2"
          src="part1.mp4"
          trimBefore={160}
          durationInFrames={288}
          zoomFrom={1.02}
          zoomTo={1.08}
        />
      </Sequence>

      {/* Моушн-врезка стоит ровно на том слове, которое иллюстрирует. */}
      <Sequence name="Моушн — предмет" from={510} durationInFrames={111}>
        <SceneOrnament durationInFrames={111} />
      </Sequence>

      <Sequence name="Лицо 3" from={621} durationInFrames={164}>
        <Clip
          name="Лицо 3"
          src="part1.mp4"
          trimBefore={613}
          durationInFrames={164}
          zoomFrom={1.03}
          zoomTo={1.09}
        />
      </Sequence>

      <Sequence name="Моушн — система решений" from={785} durationInFrames={186}>
        <SceneSpec
          title="СИСТЕМА РЕШЕНИЙ"
          rows={[
            { key: "ПАРАМЕТР", value: "ЗНАЧЕНИЕ", at: 16 },
            { key: "ПАРАМЕТР", value: "ЗНАЧЕНИЕ", at: 42 },
            { key: "ПАРАМЕТР", value: "ЗНАЧЕНИЕ", at: 68 },
            { key: "ПАРАМЕТР", value: "ЗНАЧЕНИЕ", at: 108 },
            { key: "РЕШЕНИЙ ПРИНЯТО", value: "ДЕСЯТКИ", at: 158 },
          ]}
        />
      </Sequence>

      <Sequence name="Лицо 4 — панч" from={971} durationInFrames={DURATION_IN_FRAMES - 971}>
        <Clip
          name="Лицо 4 — панч"
          src="part1.mp4"
          trimBefore={1264}
          durationInFrames={DURATION_IN_FRAMES - 971}
          zoomFrom={1.04}
          zoomTo={1.13}
        />
      </Sequence>

      {/* ── фактура: поверх всей картинки, но под текстом ────────── */}

      <Sequence name="Фактура" from={0} durationInFrames={DURATION_IN_FRAMES}>
        <Texture />
      </Sequence>

      {/* ── звук ─────────────────────────────────────────────────── */}

      {/* Чищеный стем из clean-voice.sh, а не дорожка mp4. */}
      <Voice src="part1_voice.wav" />

      {/*
        Подложка. Если в public/music/ ничего нет — убери эту строку
        и скажи об этом в ответе: ролик без музыки лучше ролика
        со случайным треком.
      */}
      <Music
        src="music/drone.mp3"
        durationInFrames={DURATION_IN_FRAMES}
        gain={0.9}
      />

      {/* ── текст ────────────────────────────────────────────────── */}

      <Sequence name="Затемнение снизу" from={0} durationInFrames={DURATION_IN_FRAMES}>
        <BottomScrim />
      </Sequence>

      {/* Титры — отдельная дорожка, двигается независимо от видео. */}
      <Captions />
    </AbsoluteFill>
  );
};
