import {
  AbsoluteFill,
  Easing,
  interpolate,
  useCurrentFrame,
} from "remotion";
import { DURIK_FONT_FAMILY } from "../fonts";
import { HIGHLIGHT_COLOR } from "./style";

/**
 * Разметка поверх живого кадра — приём VOX.
 *
 * Разница между «показать кадр» и «объяснить кадр» в том, что во втором
 * случае на кадре нарисовано, куда смотреть. Vox обводит предмет от руки,
 * тянет к нему стрелку, подписывает — и зритель видит то же, что автор.
 *
 * Когда это работает: Катя держит в кадре предмет и про него говорит.
 * Обводка появляется ровно на слове, живёт 20–40 кадров и уходит.
 * Когда не работает: обводить лицо, обводить «вообще», держать разметку
 * дольше фразы. Разметка — указка, а не оформление.
 *
 * Всё рисуется штрихом, который выбегает (strokeDashoffset), а не появляется
 * целиком: рука, которая рисует, читается как мысль, которая формулируется.
 *
 * Координаты в системе кадра 1920×1080. Снимай их со стоп-кадра:
 *   npx remotion still <id> /tmp/f.png --frame=NNN
 */

const DRAW = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** Обводка от руки: слегка неровный эллипс, как маркером. */
export const Circle: React.FC<{
  cx: number;
  cy: number;
  rx: number;
  ry: number;
  /** Наклон обводки в градусах — небольшой, иначе выглядит нарочито. */
  rotate?: number;
  /** За сколько кадров прочерчивается. */
  drawIn?: number;
  /** Кадр, на котором начинает уходить. */
  fadeAt?: number;
  color?: string;
  width?: number;
}> = ({
  cx,
  cy,
  rx,
  ry,
  rotate = -6,
  drawIn = 14,
  fadeAt,
  color = HIGHLIGHT_COLOR,
  width = 7,
}) => {
  const frame = useCurrentFrame();
  // обводка идёт на полтора оборота: конец заходит за начало, как рукой
  const len = Math.PI * 2 * Math.sqrt((rx * rx + ry * ry) / 2) * 1.5;

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <svg width={1920} height={1080}>
        <g transform={`translate(${cx} ${cy}) rotate(${rotate})`}>
          <ellipse
            rx={rx}
            ry={ry}
            fill="none"
            stroke={color}
            strokeWidth={width}
            strokeLinecap="round"
            strokeDasharray={len}
            strokeDashoffset={interpolate(frame, [0, drawIn], [len, 0], {
              ...DRAW,
              easing: Easing.bezier(0.4, 0, 0.3, 1),
            })}
            opacity={
              fadeAt === undefined
                ? 1
                : interpolate(frame, [fadeAt, fadeAt + 8], [1, 0], DRAW)
            }
          />
        </g>
      </svg>
    </AbsoluteFill>
  );
};

/** Стрелка от подписи к предмету. Рисуется от хвоста к острию. */
export const Arrow: React.FC<{
  from: [number, number];
  to: [number, number];
  /** Изгиб в пикселях: 0 — прямая, 60–120 — живая дуга. */
  bend?: number;
  drawIn?: number;
  fadeAt?: number;
  color?: string;
  width?: number;
}> = ({
  from,
  to,
  bend = 80,
  drawIn = 12,
  fadeAt,
  color = HIGHLIGHT_COLOR,
  width = 6,
}) => {
  const frame = useCurrentFrame();
  const [x1, y1] = from;
  const [x2, y2] = to;
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  // контрольная точка сдвинута по нормали к отрезку — отсюда дуга
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const cxp = mx - (dy / len) * bend;
  const cyp = my + (dx / len) * bend;

  const t = interpolate(frame, [0, drawIn], [0, 1], {
    ...DRAW,
    easing: Easing.bezier(0.4, 0, 0.3, 1),
  });
  const opacity =
    fadeAt === undefined
      ? 1
      : interpolate(frame, [fadeAt, fadeAt + 8], [1, 0], DRAW);

  // угол острия берём из касательной в конце кривой
  const angle = (Math.atan2(y2 - cyp, x2 - cxp) * 180) / Math.PI;
  const head = interpolate(frame, [drawIn - 2, drawIn + 4], [0, 1], DRAW);

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <svg width={1920} height={1080}>
        <path
          d={`M${x1} ${y1} Q${cxp} ${cyp} ${x2} ${y2}`}
          fill="none"
          stroke={color}
          strokeWidth={width}
          strokeLinecap="round"
          strokeDasharray={len * 1.6}
          strokeDashoffset={len * 1.6 * (1 - t)}
          opacity={opacity}
        />
        <g
          transform={`translate(${x2} ${y2}) rotate(${angle}) scale(${head})`}
          opacity={opacity}
        >
          <path
            d="M0 0 L-30 -13 L-30 13 Z"
            fill={color}
          />
        </g>
      </svg>
    </AbsoluteFill>
  );
};

/** Подпись к разметке. Мелкая, разрядкой — не спорит с субтитрами. */
export const Note: React.FC<{
  text: string;
  x: number;
  y: number;
  appearsAt?: number;
  fadeAt?: number;
  align?: "left" | "center" | "right";
  color?: string;
}> = ({
  text,
  x,
  y,
  appearsAt = 0,
  fadeAt,
  align = "left",
  color = HIGHLIGHT_COLOR,
}) => {
  const frame = useCurrentFrame();

  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        transform:
          align === "center"
            ? "translateX(-50%)"
            : align === "right"
              ? "translateX(-100%)"
              : undefined,
        fontFamily: DURIK_FONT_FAMILY,
        fontSize: 46,
        letterSpacing: 6,
        color,
        textShadow: "0 4px 24px rgba(0,0,0,0.8)",
        whiteSpace: "pre",
        pointerEvents: "none",
        opacity:
          interpolate(frame, [appearsAt, appearsAt + 7], [0, 1], DRAW) *
          (fadeAt === undefined
            ? 1
            : interpolate(frame, [fadeAt, fadeAt + 8], [1, 0], DRAW)),
        translate: interpolate(
          frame,
          [appearsAt, appearsAt + 12],
          ["0px 10px", "0px 0px"],
          { ...DRAW, easing: Easing.bezier(0.16, 1, 0.3, 1) },
        ),
      }}
    >
      {text}
    </div>
  );
};
