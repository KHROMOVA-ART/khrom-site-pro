/**
 * Пересобирает src/index.css, вшивая public/DURIK.ttf как data URI.
 * Запускать, если поменялся файл шрифта:  node inline-font.mjs
 */
import fs from "fs";

const b = fs.readFileSync("public/DURIK.ttf").toString("base64");
const css = fs.readFileSync("src/index.css", "utf8");
fs.writeFileSync(
  "src/index.css",
  css.replace(/url\("data:font\/ttf;base64,[^"]*"\)/, `url("data:font/ttf;base64,${b}")`),
);
console.log("шрифт обновлён в src/index.css");
