#!/bin/bash
# Печёт текстуры в public/tex/: зерно и бумагу.
#
#   bash make-textures.sh <проект>
#
# Почему файлами, а не feTurbulence прямо в компоненте: SVG-шум на весь кадр
# пересчитывается каждый кадр и раздувает рендер в разы. Готовая плитка
# 512×512, которую браузер только двигает и повторяет, стоит примерно ноль.
#
# Делается один раз на проект. Файлы маленькие (~250 КБ на двоих).
set -euo pipefail

PROJECT="${1:?Использование: make-textures.sh <проект>}"
FFMPEG="$PROJECT/node_modules/ffmpeg-static/ffmpeg"
DIR="$PROJECT/public/tex"
mkdir -p "$DIR"

# Зерно: жёсткий белый шум. Кладётся поверх кадра в overlay на 6–10%
# и слегка двигается — тогда картинка «дышит», как плёнка. Плитка 512×512
# повторяется: у белого шума стыков не видно.
"$FFMPEG" -y -v error -f lavfi -i "nullsrc=s=512x512,format=gray" \
  -vf "geq=lum='random(1)*255',format=gray" -frames:v 1 "$DIR/grain.png"

# Бумага: два масштаба шума вокруг серого 128.
#   мелкий (blur 0.6)  — волокно
#   крупный (blur 22)  — облачность и неровность листа
# Серединой ровно на 128 — потому что кладётся в mixBlendMode: overlay,
# где 50% серого не меняет ничего, а отклонения от него и дают фактуру.
# Края обрезаются: gblur на границе кадра даёт тёмную кайму.
"$FFMPEG" -y -v error -f lavfi -i "nullsrc=s=1024x1024,format=gray" \
  -vf "geq=lum='random(1)*255',format=gray,gblur=sigma=0.6,eq=contrast=0.22" \
  -frames:v 1 "${DIR}/.fiber.png"

"$FFMPEG" -y -v error -f lavfi -i "nullsrc=s=1024x1024,format=gray" \
  -vf "geq=lum='random(1)*255',format=gray,gblur=sigma=22,eq=contrast=3.2" \
  -frames:v 1 "${DIR}/.mottle.png"

"$FFMPEG" -y -v error -i "${DIR}/.fiber.png" -i "${DIR}/.mottle.png" \
  -filter_complex "[0][1]blend=all_mode=average,crop=900:900:62:62,format=gray" \
  -frames:v 1 "$DIR/paper.png"

rm -f "${DIR}/.fiber.png" "${DIR}/.mottle.png"

ls -la "$DIR"
echo
echo "Готово. Подключается через <Grain /> и <Paper /> из Texture.tsx."
