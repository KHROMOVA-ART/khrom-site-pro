#!/bin/bash
# Кладёт исходники в public/ проекта в виде partN.mp4 (H.264) и готовит
# partN_16k.wav для расшифровки.
#
#   bash prepare-sources.sh <путь-к-проекту> "первая часть.MOV" "вторая часть.MOV"
#
# Порядок аргументов = порядок клипов на таймлайне.
set -euo pipefail

if [ "$#" -lt 2 ]; then
  echo "Использование: prepare-sources.sh <проект> <исходник> [исходник…]" >&2
  exit 1
fi

PROJECT="$1"; shift
FFMPEG="$PROJECT/node_modules/ffmpeg-static/ffmpeg"
FFPROBE=$(ls "$PROJECT"/node_modules/ffprobe-static/bin/darwin/*/ffprobe 2>/dev/null | head -1)
WAVDIR="${WAVDIR:-${TMPDIR:-/tmp}}"

[ -x "$FFMPEG" ] || { echo "Не найден ffmpeg: $FFMPEG" >&2; exit 1; }

mkdir -p "$PROJECT/public"
i=0
for SRC in "$@"; do
  i=$((i + 1))
  OUT="$PROJECT/public/part$i.mp4"
  WAV="$WAVDIR/part${i}_16k.wav"

  # -map 0:v:0 -map 0:a:0 отсекает служебные data-дорожки iPhone,
  # из-за которых Remotion иногда спотыкается.
  "$FFMPEG" -y -v error -i "$SRC" \
    -map 0:v:0 -map 0:a:0 \
    -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p \
    -c:a aac -b:a 192k \
    "$OUT"

  "$FFMPEG" -y -v error -i "$OUT" -ar 16000 -ac 1 -c:a pcm_s16le "$WAV"

  if [ -n "$FFPROBE" ]; then
    INFO=$("$FFPROBE" -v error -select_streams v:0 \
      -show_entries stream=width,height,r_frame_rate \
      -show_entries format=duration \
      -of csv=p=0:s=" " "$OUT" | tr '\n' ' ')
    echo "part$i.mp4  ← $SRC   $INFO"
  else
    echo "part$i.mp4  ← $SRC"
  fi
  echo "  wav: $WAV"
done

echo
echo "Дальше: node transcribe.mjs $PROJECT part1 …  и  node loudness-map.mjs part1 …"
