/**
 * Меряет грейд: яркость, насыщенность и оттенок насыщенных пикселей.
 *
 *   node measure-grade.mjs <проект> <файл.mp4|png> [кадр ...]
 *   node measure-grade.mjs reel-remotion out/reel.mp4 100 400 900
 *   node measure-grade.mjs reel-remotion /tmp/chk.png
 *
 * Тем же способом мерился референс, поэтому цифры сравнимы напрямую.
 * Ориентир (basov.pro):
 *
 *   средняя яркость          0,21
 *   медианная насыщенность   0,12
 *   насыщенность верхних 5%  0,76
 *   оттенок насыщенных       0–30°
 *
 * Смотреть надо на все четыре сразу. Одна средняя яркость ничего не говорит:
 * равномерно притушенный кадр и кадр с сохранённым тёплым акцентом дают
 * одинаковую яркость и совершенно разное впечатление.
 */
import fs from "fs";
import path from "path";
import { execFileSync } from "child_process";

const [projectArg, file, ...frames] = process.argv.slice(2);
if (!projectArg || !file) {
  console.error("Использование: node measure-grade.mjs <проект> <файл> [кадр ...]");
  process.exit(1);
}

// Путь к проекту принимаем и абсолютный, и относительный, и уже «изнутри»:
// иначе `node …/measure-grade.mjs reel-remotion …` из самой папки проекта
// молча складывается в reel-remotion/reel-remotion и падает на ENOENT.
const candidates = [
  path.resolve(projectArg),
  process.cwd(),
  path.resolve(process.cwd(), ".."),
];
const project = candidates.find((d) =>
  fs.existsSync(path.join(d, "node_modules/ffmpeg-static/ffmpeg")),
);
if (!project) {
  console.error("Не нашёл ffmpeg-static ни в " + candidates.join(", "));
  process.exit(1);
}
const ffmpeg = path.join(project, "node_modules/ffmpeg-static/ffmpeg");
const W = 160;
const H = 90;

/** Кадр → сырой rgb24 уменьшённого размера. */
const grab = (src, frame) => {
  const args = ["-v", "error"];
  if (frame !== undefined) args.push("-vf", `select='eq(n\\,${frame})',scale=${W}:${H}`, "-vsync", "0");
  else args.push("-vf", `scale=${W}:${H}`);
  return execFileSync(
    ffmpeg,
    ["-i", src, ...args, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
    { maxBuffer: 1 << 28 },
  );
};

const analyse = (buf) => {
  const sats = [];
  let lum = 0;
  const hueBins = new Array(12).fill(0);
  let warm = 0;
  const n = buf.length / 3;

  for (let i = 0; i < buf.length; i += 3) {
    const r = buf[i] / 255;
    const g = buf[i + 1] / 255;
    const b = buf[i + 2] / 255;
    const mx = Math.max(r, g, b);
    const mn = Math.min(r, g, b);
    const s = mx === 0 ? 0 : (mx - mn) / mx;
    sats.push(s);
    lum += 0.2126 * r + 0.7152 * g + 0.0722 * b;

    if (s > 0.35 && mx > 0.15) {
      const d = mx - mn;
      let h = 0;
      if (d > 0) {
        if (mx === r) h = ((g - b) / d + 6) % 6;
        else if (mx === g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
      }
      const deg = h * 60;
      hueBins[Math.floor(deg / 30) % 12]++;
      if (deg < 30 || deg >= 330) warm++;
    }
  }

  sats.sort((a, b) => a - b);
  const saturated = hueBins.reduce((a, b) => a + b, 0);
  return {
    lum: lum / n,
    median: sats[Math.floor(n / 2)],
    p95: sats[Math.floor(n * 0.95)],
    saturatedShare: saturated / n,
    warmShare: saturated ? warm / saturated : 0,
    topHue: hueBins.indexOf(Math.max(...hueBins)) * 30,
  };
};

const REF = { lum: 0.21, median: 0.12, p95: 0.76 };
const mark = (v, target, tol) => (Math.abs(v - target) <= tol ? "✓" : "→");

console.log(`\n${file}`);
console.log("кадр    яркость   медиана   верх.5%   насыщ.доля  тёплых  осн.тон");

for (const f of frames.length ? frames : [undefined]) {
  const a = analyse(grab(path.resolve(file), f));
  console.log(
    [
      String(f ?? "—").padStart(5),
      `${a.lum.toFixed(3)} ${mark(a.lum, REF.lum, 0.05)}`.padStart(11),
      `${a.median.toFixed(3)} ${mark(a.median, REF.median, 0.05)}`.padStart(10),
      `${a.p95.toFixed(3)} ${mark(a.p95, REF.p95, 0.15)}`.padStart(10),
      a.saturatedShare.toFixed(3).padStart(11),
      `${Math.round(a.warmShare * 100)}%`.padStart(7),
      `${a.topHue}°`.padStart(8),
    ].join(""),
  );
}

console.log(
  `\nориентир: яркость ${REF.lum}  медиана ${REF.median}  верх.5% ${REF.p95}  осн.тон 0°`,
);
console.log("«тёплых» — доля красно-оранжевого среди насыщенных пикселей.\n");
