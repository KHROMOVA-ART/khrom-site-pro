/**
 * Карта громкости исходника — тем, чем проверяют расшифровку.
 *
 *   node loudness-map.mjs part1 part2
 *
 * Строка = 10 секунд, символ = 0,1 с, отсчёт от пика файла:
 *   #  громко      (> −18 dB)   — уверенная речь
 *   +  средне      (> −26 dB)
 *   .  тихо        (> −34 dB)   — тихая речь, вдох, «эээ»
 *   пробел         тишина       — здесь речи нет, что бы ни утверждал whisper
 *
 * Ниже карты печатается список речевых кусков — по ним и строятся тайминги
 * субтитров. Если слово из расшифровки попадает в пробел, слово выдумано
 * или уехало по времени.
 *
 * Ждёт <part>_16k.wav в $WAVDIR (или $TMPDIR, или /tmp) — их делает
 * prepare-sources.sh.
 */
import fs from "fs";
import path from "path";

const parts = process.argv.slice(2);
if (parts.length === 0) {
  console.error("Использование: node loudness-map.mjs part1 [part2…]");
  process.exit(1);
}

const wavDir = process.env.WAVDIR ?? process.env.TMPDIR ?? "/tmp";
const WINDOW_SECONDS = 0.1;
const SAMPLE_RATE = 16000;
/** Дырка короче этого — дыхание внутри фразы, а не пауза между репликами. */
const MIN_GAP_SECONDS = 0.25;

for (const part of parts) {
  const file = path.join(wavDir, `${part}_16k.wav`);
  const buf = fs.readFileSync(file);

  // Ищем чанк data: у .wav с айфона перед ним бывает лишний чанк.
  let offset = 12;
  while (buf.toString("ascii", offset, offset + 4) !== "data") {
    offset += 8 + buf.readUInt32LE(offset + 4);
  }
  const dataStart = offset + 8;
  const sampleCount = buf.readUInt32LE(offset + 4) / 2;
  const window = SAMPLE_RATE * WINDOW_SECONDS;

  const frames = [];
  for (let i = 0; i + window <= sampleCount; i += window) {
    let sum = 0;
    for (let k = 0; k < window; k++) {
      const v = buf.readInt16LE(dataStart + (i + k) * 2) / 32768;
      sum += v * v;
    }
    frames.push(10 * Math.log10(sum / window + 1e-12));
  }

  const peak = Math.max(...frames);
  const symbols = frames
    .map((db) => db - peak)
    .map((rel) => (rel > -18 ? "#" : rel > -26 ? "+" : rel > -34 ? "." : " "));

  console.log(`\n=== ${part}   пик ${peak.toFixed(1)} dB   ${(frames.length / 10).toFixed(1)} с`);
  const line = symbols.join("");
  for (let i = 0; i < line.length; i += 100) {
    console.log(`${String(i / 10).padStart(4)}s |${line.slice(i, i + 100)}`);
  }

  // Речевые куски: склеиваем всё, что громче тишины, через короткие дырки.
  const gapFrames = MIN_GAP_SECONDS / WINDOW_SECONDS;
  const segments = [];
  let start = null;
  let silence = 0;
  symbols.forEach((s, i) => {
    if (s !== " ") {
      if (start === null) start = i;
      silence = 0;
    } else if (start !== null && ++silence >= gapFrames) {
      segments.push([start / 10, (i - silence + 1) / 10]);
      start = null;
    }
  });
  if (start !== null) segments.push([start / 10, symbols.length / 10]);

  console.log("\nречь:");
  for (const [a, b] of segments) {
    console.log(`  ${a.toFixed(2)} – ${b.toFixed(2)}   (${(b - a).toFixed(2)} с)`);
  }
  const speech = segments.reduce((acc, [a, b]) => acc + (b - a), 0);
  console.log(
    `  итого речи ${speech.toFixed(1)} с из ${(frames.length / 10).toFixed(1)} с файла`,
  );
}
