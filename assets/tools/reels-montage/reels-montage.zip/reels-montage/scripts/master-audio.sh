#!/bin/bash
# Финальное сведение громкости готового ролика.
#
#   bash master-audio.sh <проект> out/имя.mp4 [<цель-LUFS>]
#
# Берёт отрендеренный файл, приводит весь микс (голос + музыка) к −14 LUFS
# и −1 dBTP, видео при этом просто копируется — перекодирования картинки нет,
# качество не теряется, занимает секунды.
#
# −14 LUFS / −1 dBTP — то, к чему нормализуют Instagram и TikTok. Если отдать
# тише, площадка не поднимет, и ролик прозвучит слабее соседних в ленте.
# Если отдать громче — прижмёт своим лимитером, и прижмёт грубее, чем свой.
#
# Результат кладётся рядом: имя_master.mp4. Исходный рендер не трогается —
# если что-то не понравилось на слух, есть к чему вернуться.
set -euo pipefail

PROJECT="${1:?Использование: master-audio.sh <проект> <файл.mp4> [цель]}"
FILE="${2:?Укажи отрендеренный mp4}"
TARGET="${3:--14}"

FFMPEG="$PROJECT/node_modules/ffmpeg-static/ffmpeg"
OUT="${FILE%.*}_master.mp4"
TMP="${TMPDIR:-/tmp}/master_$$.wav"
TMP2="${TMPDIR:-/tmp}/master_$$_b.wav"

measure() {
  "$FFMPEG" -hide_banner -i "$1" -af ebur128=framelog=quiet -f null /dev/null 2>&1 |
    grep -A2 "Integrated loudness" | grep "I:" | awk '{print $2}'
}

echo "→ было: $(measure "$FILE") LUFS"

"$FFMPEG" -y -v error -i "$FILE" -map 0:a:0 -ar 48000 -c:a pcm_s24le "$TMP"

for _ in 1 2; do
  I=$(measure "$TMP")
  G=$(python3 -c "print(round($TARGET - ($I), 2))")
  if [ "$G" = "0.0" ] || [ "$G" = "0" ]; then break; fi
  echo "   добавляю ${G} dB"
  "$FFMPEG" -y -v error -i "$TMP" -af "volume=${G}dB,alimiter=limit=0.891:level=false" \
    -ar 48000 -c:a pcm_s24le "$TMP2"
  mv "$TMP2" "$TMP"
done

# Видео копируем как есть, меняем только звук.
# apad перед -shortest обязателен: звуковая дорожка кончается на последнем
# слове, и без добивки тишиной -shortest обрежет по ней видео — вместе
# с хвостовыми кадрами.
"$FFMPEG" -y -v error -i "$FILE" -i "$TMP" \
  -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 256k \
  -af apad -shortest "$OUT"

rm -f "$TMP"

echo
echo "$OUT"
echo "  стало: $(measure "$OUT") LUFS"
