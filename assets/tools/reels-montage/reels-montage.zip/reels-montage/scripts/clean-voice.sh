#!/bin/bash
# Чистит дорожку монолога и приводит её к предсказуемой громкости.
#
#   bash clean-voice.sh <проект> <файл-в-public> [<имя-выхода>] [<цель-LUFS>]
#   bash clean-voice.sh reel-remotion v3987.mp4 v3987
#
# Кладёт в public/<имя>_voice.wav дорожку той же длины и с тем же началом,
# что и исходник, — все trimBefore в кадрах остаются валидными.
#
# Что делает и зачем:
#
#   highpass 85 Гц  гул комнаты и стук пальцев по корпусу телефона;
#                   в голосе ниже 85 Гц полезного нет
#   deesser         свистящие: iPhone пишет с близкого расстояния, «с» режет
#   acompressor     сжимает динамику, чтобы тихие фразы не проваливались;
#                   3:1 — ещё разговор, а не радиоведущий
#   volume+alimiter приводит к цели по EBU R128
#
# ШУМОДАВА ЗДЕСЬ НЕТ И БОЛЬШЕ НЕ БУДЕТ. Тут стоял afftdn «мягко, всего
# nr=12» — Катя услышала его на готовом ролике и попросила убрать совсем:
# на её записях шума почти нет (SNR около 37 dB), а спектральный шумодав
# на таком материале съедает воздух и верх голоса и даёт то самое
# «из-под воды». Не возвращай afftdn, anlmdn и прочие шумодавы, даже
# самыми щадящими параметрами и даже если запись кажется шумной:
# сначала спроси. Громкость даёт компрессор и вывод на LUFS, а не шумодав.
#
# Почему −16 LUFS, а не −14, к которым нормализуют площадки: −14 просят
# для ГОТОВОГО микса. Голос — стем, под него ещё ляжет музыка, и сумма
# выйдет как раз около −14. Финальный микс доводится отдельно, уже на
# отрендеренном файле — master-audio.sh.
#
# Почему цикл, а не loudnorm: динамический режим loudnorm в ffmpeg
# систематически недобирает 2–3 LU, а лимитер съедает ещё. Померить —
# подвинуть — померить сходится за один проход и даёт ровно то, что просили.
set -euo pipefail

PROJECT="${1:?Использование: clean-voice.sh <проект> <файл-в-public> [имя] [цель]}"
SRC="${2:?Укажи файл из public/, например v3987.mp4}"
NAME="${3:-${SRC%.*}}"
TARGET="${4:--16}"

FFMPEG="$PROJECT/node_modules/ffmpeg-static/ffmpeg"
IN="$PROJECT/public/$SRC"
OUT="$PROJECT/public/${NAME}_voice.wav"
TMP="${TMPDIR:-/tmp}/clean_${NAME}_$$.wav"
TMP2="${TMPDIR:-/tmp}/clean_${NAME}_$$_b.wav"

CLEAN="highpass=f=85,deesser=i=0.35,acompressor=threshold=-24dB:ratio=3:attack=5:release=140:makeup=3"

measure() {
  "$FFMPEG" -hide_banner -i "$1" -af ebur128=framelog=quiet -f null /dev/null 2>&1 |
    grep -A2 "Integrated loudness" | grep "I:" | awk '{print $2}'
}

echo "→ чищу: highpass · deesser · компрессия (шумодава нет)"
"$FFMPEG" -y -v error -i "$IN" -map 0:a:0 -af "$CLEAN" \
  -ar 48000 -ac 1 -c:a pcm_s16le "$TMP"

echo "→ вывожу на ${TARGET} LUFS"
for _ in 1 2; do
  I=$(measure "$TMP")
  G=$(python3 -c "print(round($TARGET - ($I), 2))")
  echo "   сейчас ${I} LUFS, добавляю ${G} dB"
  # выход на 0 dB не трогаем: значит уже сошлось
  if [ "$G" = "0.0" ] || [ "$G" = "0" ]; then break; fi
  "$FFMPEG" -y -v error -i "$TMP" -af "volume=${G}dB,alimiter=limit=0.95:level=false" \
    -ar 48000 -ac 1 -c:a pcm_s16le "$TMP2"
  mv "$TMP2" "$TMP"
done

mv "$TMP" "$OUT"

echo
echo "$OUT"
echo "  громкость: $(measure "$OUT") LUFS"
echo "  пик:       $("$FFMPEG" -hide_banner -i "$OUT" -af volumedetect -f null /dev/null 2>&1 | grep max_volume | sed 's/.*: //')"
echo
echo "Дальше: в Voice.tsx подставь src=\"${NAME}_voice.wav\" вместо mp4."
