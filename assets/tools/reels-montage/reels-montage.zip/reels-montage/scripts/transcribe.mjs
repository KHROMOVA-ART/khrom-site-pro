/**
 * Расшифровка исходников через whisper.cpp (модель medium) с пословными
 * таймкодами.
 *
 *   node transcribe.mjs <проект> part1 part2
 *   node transcribe.mjs <проект> --slice part1:22.5:6.5
 *
 * Обычный режим печатает слова с таймкодами и складывает их в
 * <tmp>/<part>_words.json.
 *
 * Режим --slice расшифровывает кусок <part>:<начало>:<длина> с поднятой
 * громкостью — им проверяют места, где расшифровка расходится с картой
 * громкости. На коротком фрагменте whisper заметно точнее, а таймкоды
 * в выводе уже пересчитаны в абсолютные секунды исходника.
 */
import fs from "fs";
import path from "path";
import { createRequire } from "module";
import { execFileSync } from "child_process";

const [projectArg, ...rest] = process.argv.slice(2);
if (!projectArg || rest.length === 0) {
  console.error("Использование: node transcribe.mjs <проект> part1 [part2…]");
  console.error("           или: node transcribe.mjs <проект> --slice part1:22.5:6.5");
  process.exit(1);
}

const project = path.resolve(projectArg);
const wavDir = process.env.WAVDIR ?? process.env.TMPDIR ?? "/tmp";
const whisperPath = path.join(project, "whisper.cpp");

// Скрипт лежит в скилле, а пакеты — в проекте, поэтому резолвим от проекта.
const require = createRequire(path.join(project, "package.json"));
const { downloadWhisperModel, installWhisperCpp, transcribe, toCaptions } =
  require("@remotion/install-whisper-cpp");

await installWhisperCpp({ to: whisperPath, version: "1.5.5" });
await downloadWhisperModel({ model: "medium", folder: whisperPath });

const run = (inputPath, tokenLevel) =>
  transcribe({
    model: "medium",
    whisperPath,
    whisperCppVersion: "1.5.5",
    inputPath,
    tokenLevelTimestamps: tokenLevel,
    language: "ru",
  });

/** Токены whisper → слова: продолжения слова не начинаются с пробела. */
const toWords = (captions) => {
  const words = [];
  for (const token of captions) {
    const clean = token.text.trim();
    if (!clean) continue;
    if (token.text.startsWith(" ") || words.length === 0) {
      words.push({ text: clean, start: token.startMs / 1000, end: token.endMs / 1000 });
    } else {
      const last = words[words.length - 1];
      last.text += clean;
      last.end = token.endMs / 1000;
    }
  }
  return words;
};

if (rest[0] === "--slice") {
  const ffmpeg = path.join(project, "node_modules/ffmpeg-static/ffmpeg");
  for (const spec of rest.slice(1)) {
    const [part, from, length] = spec.split(":");
    const slicePath = path.join(wavDir, `slice_${part}_${from}.wav`);
    // +8 dB: тихая речь на границе шума иначе распознаётся как тишина.
    execFileSync(ffmpeg, [
      "-y", "-v", "error",
      "-ss", from, "-t", length,
      "-i", path.join(wavDir, `${part}_16k.wav`),
      "-af", "volume=8dB", "-ar", "16000", "-ac", "1", slicePath,
    ]);

    const out = await run(slicePath, false);
    const offset = Number(from);
    console.log(`\n=== ${part} ${from}s +${length}s`);
    for (const seg of out.transcription) {
      const a = (offset + seg.offsets.from / 1000).toFixed(2);
      const b = (offset + seg.offsets.to / 1000).toFixed(2);
      console.log(`${a}-${b} ${seg.text}`);
    }
  }
} else {
  for (const part of rest) {
    const out = await run(path.join(wavDir, `${part}_16k.wav`), true);
    const { captions } = toCaptions({ whisperCppOutput: out });
    const words = toWords(captions);
    fs.writeFileSync(
      path.join(wavDir, `${part}_words.json`),
      JSON.stringify(words, null, 2),
    );
    console.log(`\n=== ${part} (${words.length} слов) → ${wavDir}/${part}_words.json`);
    console.log(
      words.map((w) => `${w.start.toFixed(2)}-${w.end.toFixed(2)} ${w.text}`).join("\n"),
    );
  }
  console.log(
    "\nТеперь обязательно сверь это с картой громкости: node loudness-map.mjs " +
      rest.join(" "),
  );
}
