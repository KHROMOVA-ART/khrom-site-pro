/**
 * Сборка дорожки речи без пауз и междометий.
 *
 * Обязательный шаг во всех трёх режимах монтажа: паузы и междометия
 * вырезаются всегда (SKILL.md, раздел 3).
 *
 *   node tighten-speech.mjs <проект> part1 [part2…] [--max-pause=0.12] [--gap=3]
 *
 * Куски строятся ПО ТИШИНЕ, а слова из расшифровки только подписывают их
 * и ловят междометия. Так и должно быть: whisper с пословными таймкодами
 * покрывает файл сплошняком — у него между словами не бывает дырок вообще,
 * — а тишина не врёт. Отсюда же вытекает, что порог тишины считается
 * от пика файла, а не берётся абсолютным: Катины ночные записи приходят
 * с пиком −25 dB, и фиксированные −32 dB объявили бы тишиной всю речь.
 *
 * Решения, которые скрипт не принимает сам:
 *  • слова-паразиты (ну, вот, типа…) он только помечает — режь их руками,
 *    проверив, держат ли они фразу. Ключ --cut-parasites режет сразу;
 *  • кусок короче --min-chunk он выбрасывает как шум и пишет об этом:
 *    вдох, стук по кровати и «спасибо за внимание» от whisper живут именно там.
 */
import fs from "fs";
import path from "path";
import { spawnSync } from "child_process";

const argv = process.argv.slice(2);
const flags = Object.fromEntries(
  argv
    .filter((a) => a.startsWith("--"))
    .map((a) => {
      const [k, v] = a.replace(/^--/, "").split("=");
      return [k, v === undefined ? true : v];
    }),
);
const positional = argv.filter((a) => !a.startsWith("--"));
const [projectArg, ...parts] = positional;

if (!projectArg || parts.length === 0) {
  console.error(
    "Использование: node tighten-speech.mjs <проект> part1 [part2…] [--max-pause=0.12] [--gap=3]",
  );
  process.exit(1);
}

const project = path.resolve(projectArg);
const wavDir = process.env.WAVDIR ?? process.env.TMPDIR ?? "/tmp";
const ffmpeg = path.join(project, "node_modules/ffmpeg-static/ffmpeg");

const MAX_PAUSE = Number(flags["max-pause"] ?? 0.12);
const GAP = Number(flags.gap ?? 3);
const PAD = Number(flags.pad ?? 0.05);
const FPS = Number(flags.fps ?? 30);
/** Кусок короче этого — не речь, а шум. */
const MIN_CHUNK = Number(flags["min-chunk"] ?? 0.25);
/** На сколько dB ниже пика начинается тишина. */
const BELOW_PEAK = Number(flags["below-peak"] ?? 27);
const CUT_PARASITES = Boolean(flags["cut-parasites"]);

/** Нефонемные — режутся всегда. */
const NOISE = new Set(
  "э ээ эээ ээээ ы ыы ыыы а аа ааа м мм ммм эм эмм кхм хм угу ага uh um er ah"
    .split(" "),
);

/** Паразиты — только помечаются, если не задан --cut-parasites. */
const PARASITES = new Set("ну вот типа короче значит слушай походу блин".split(" "));

const norm = (s) =>
  s.toLowerCase().replace(/ё/g, "е").replace(/[^a-zа-я-]/gi, "");

const ff = (args) => {
  const proc = spawnSync(ffmpeg, ["-hide_banner", ...args], {
    encoding: "utf8",
    maxBuffer: 64 * 1024 * 1024,
  });
  if (proc.error) throw proc.error;
  return proc.stderr ?? "";
};

/** Пик файла в dBFS — от него отсчитывается порог тишины. */
const peakDb = (wav) => {
  const out = ff(["-i", wav, "-af", "volumedetect", "-f", "null", "-"]);
  const m = out.match(/max_volume:\s*(-?[\d.]+) dB/);
  return m ? Number(m[1]) : 0;
};

/** Интервалы тишины [{from, to}] — то, чему верим больше расшифровки. */
const silences = (wav, noiseDb) => {
  const out = ff([
    "-i", wav,
    "-af", `silencedetect=noise=${noiseDb}dB:d=${MAX_PAUSE}`,
    "-f", "null", "-",
  ]);
  const res = [];
  let from = null;
  for (const line of out.split("\n")) {
    const s = line.match(/silence_start:\s*(-?[\d.]+)/);
    const e = line.match(/silence_end:\s*([\d.]+)/);
    if (s) from = Math.max(0, Number(s[1]));
    if (e && from !== null) {
      res.push({ from, to: Number(e[1]) });
      from = null;
    }
  }
  // silencedetect выдаёт перекрывающиеся куски — склеиваем.
  res.sort((a, b) => a.from - b.from);
  const merged = [];
  for (const s of res) {
    const last = merged[merged.length - 1];
    if (last && s.from <= last.to + 0.001) last.to = Math.max(last.to, s.to);
    else merged.push({ ...s });
  }
  return { list: merged, tail: from };
};

for (const part of parts) {
  const wavPath = path.join(wavDir, `${part}_16k.wav`);
  const wordsPath = path.join(wavDir, `${part}_words.json`);
  if (!fs.existsSync(wordsPath)) {
    console.error(`Нет ${wordsPath} — сначала прогони transcribe.mjs <проект> ${part}`);
    process.exit(1);
  }
  const words = JSON.parse(fs.readFileSync(wordsPath, "utf8"));
  const duration = words[words.length - 1].end;

  const peak = peakDb(wavPath);
  const noiseDb = flags.noise ? Number(flags.noise) : Math.round(peak - BELOW_PEAK);
  const { list: sil, tail } = silences(wavPath, noiseDb);

  // Речь = всё, что не тишина.
  const speech = [];
  let cursor = 0;
  for (const s of sil) {
    if (s.from - cursor > 0.001) speech.push({ from: cursor, to: s.from });
    cursor = s.to;
  }
  if (tail === null && duration - cursor > 0.001)
    speech.push({ from: cursor, to: duration });

  const noiseChunks = speech.filter((s) => s.to - s.from < MIN_CHUNK);
  const kept = speech.filter((s) => s.to - s.from >= MIN_CHUNK);

  /** Слова, попадающие в интервал. */
  const wordsIn = (a, b) =>
    words.filter((w) => {
      const mid = (w.start + w.end) / 2;
      return mid >= a && mid < b;
    });

  const dropped = [];
  const flagged = [];

  const rows = [];
  kept.forEach((s) => {
    const inside = wordsIn(s.from, s.to);
    const text = inside.map((w) => w.text).join(" ").replace(/\s+([,.!?])/g, "$1").trim();

    // Кусок целиком из междометий — выкидываем.
    const meaningful = inside.filter((w) => {
      const n = norm(w.text);
      if (!n) return false;
      if (NOISE.has(n)) return false;
      if (PARASITES.has(n) && CUT_PARASITES) return false;
      return true;
    });
    if (inside.length && meaningful.length === 0) {
      dropped.push({ from: s.from, to: s.to, text, why: "междометие" });
      return;
    }
    for (const w of inside) {
      const n = norm(w.text);
      if (NOISE.has(n)) dropped.push({ from: w.start, to: w.end, text: w.text, why: "междометие в фразе" });
      else if (PARASITES.has(n)) flagged.push(w);
    }

    const start = Math.max(0, s.from - PAD);
    const end = Math.min(duration, s.to + PAD);
    rows.push({
      from: start,
      to: end,
      trimBefore: Math.round(start * FPS),
      durationInFrames: Math.max(1, Math.round((end - start) * FPS)),
      words: meaningful.length,
      text,
    });
  });

  // Куски, между которыми тишина короче MAX_PAUSE, склеиваем обратно.
  const merged = [];
  for (const r of rows) {
    const last = merged[merged.length - 1];
    if (last && r.from - last.to < MAX_PAUSE) {
      last.to = r.to;
      last.durationInFrames = Math.round((last.to - last.from) * FPS);
      last.words += r.words;
      last.text += " " + r.text;
    } else merged.push({ ...r });
  }

  const speechSec = merged.reduce((a, r) => a + r.durationInFrames / FPS, 0);
  const total = speechSec + ((merged.length - 1) * GAP) / FPS;
  const wordCount = merged.reduce((a, r) => a + r.words, 0);

  console.log(`\n=== ${part}   пик ${peak} dB, порог тишины ${noiseDb} dB`);
  console.log(`export const GAP = ${GAP};`);
  console.log("export const CHUNKS: Chunk[] = [");
  merged.forEach((r, i) => {
    const letter = String.fromCharCode(65 + (i % 26));
    const name = `${letter} — ${r.text.slice(0, 46)}${r.text.length > 46 ? "…" : ""}`;
    console.log(
      `  { name: ${JSON.stringify(name)}, trimBefore: ${r.trimBefore}, durationInFrames: ${r.durationInFrames} },`,
    );
  });
  console.log("];");

  console.log(
    `\nБыло ${duration.toFixed(1)} с → стало ${total.toFixed(1)} с ` +
      `(${merged.length} кусков, вырезано ${Math.max(0, duration - total).toFixed(1)} с)`,
  );
  console.log(
    `Темп: ${Math.round((wordCount / total) * 60)} слов/мин ` +
      `(плотная речь — 165–185; выше — верни такт перед выводом)`,
  );

  if (dropped.length) {
    console.log(`\nВыкинуто как междометие (${dropped.length}):`);
    for (const d of dropped) console.log(`  ${d.from.toFixed(2)}  «${d.text}»`);
  }
  if (noiseChunks.length) {
    console.log(`\nОтброшено как шум, короче ${MIN_CHUNK} с (${noiseChunks.length}):`);
    for (const n of noiseChunks)
      console.log(`  ${n.from.toFixed(2)}–${n.to.toFixed(2)}  «${wordsIn(n.from, n.to).map((w) => w.text).join(" ").trim()}»`);
  }
  if (flagged.length) {
    console.log(
      `\nПаразиты — реши сам, держат ли они фразу (${flagged.length}), или прогони с --cut-parasites:`,
    );
    for (const w of flagged) console.log(`  ${w.start.toFixed(2)}  «${w.text}»`);
  }

  console.log(
    "\nДальше: вставь CHUNKS в Voice.tsx и прослушай стыки. " +
      "Если речь «глотает» — подними --gap до 4, выше не надо.",
  );
}
