"""Версия 512x512 — под видео-стикеры Telegram (/newvideo) и статичные стикеры (/newpack)."""
import sys, os, math, subprocess, shutil
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

os.environ["CHROME_OUTDIR"] = os.path.join(BASE, "stickers_512_static")
os.makedirs(os.environ["CHROME_OUTDIR"], exist_ok=True)

import chrome_engine
chrome_engine.S = 512                      # рендерим сразу в размер стикера
chrome_engine.OUT = 512                    # и сохраняем без даунсемпла
import build_static

from chrome_engine import (shade_fields, colorize, compose, chrome_shade,
                           RAMP, RAMP_WARM, RAMP_GREEN, glyph_mask, POPPINS)
from build_static import drop_mask, sphere_mask, ring_mask, face_layer, fa
from PIL import Image

S = 512
OUT = os.path.join(BASE, "stickers_512_animated")
TMP = "/tmp/chrome_frames_512"
os.makedirs(OUT, exist_ok=True)
FPS, DUR = 24, 2.0
N = int(FPS * DUR)


def transform(img, scale=1.0, dy=0.0, dx=0.0, squash=1.0):
    w = max(1, int(S * scale))
    h = max(1, int(S * scale * squash))
    r = img.resize((w, h), Image.LANCZOS)
    c = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    c.paste(r, (int((S - w) / 2 + dx * S), int((S - h) / 2 + dy * S)))
    return c


def encode(name, frames, limit=250):
    """VP9+alpha, подбор crf под лимит Telegram 256 КБ"""
    shutil.rmtree(TMP, ignore_errors=True)
    os.makedirs(TMP)
    for i, f in enumerate(frames):
        f.save(f"{TMP}/f{i:03d}.png")
    dst = f"{OUT}/{name}.webm"
    for crf in (36, 42, 47, 52, 57, 62):
        subprocess.run([
            "ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS),
            "-i", f"{TMP}/f%03d.png", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
            "-b:v", "0", "-crf", str(crf), "-an", "-auto-alt-ref", "0",
            "-deadline", "good", "-cpu-used", "4", "-row-mt", "1",
            "-metadata:s:v:0", "alpha_mode=1", dst], check=True)
        kb = os.path.getsize(dst) / 1024
        if kb <= limit:
            break
    print(f"  {name}.webm  {kb:.1f} KB  crf={crf}  (лимит 256)")
    return kb


print("512x512 — анимированные:")

fld = shade_fields(drop_mask())
faces = {k: face_layer(k) for k in ("hi", "blink")}
frames = []
for i in range(N):
    p = i / N
    rgb, a = colorize(fld, tilt=0.10 * math.sin(2 * math.pi * p))
    img = compose(rgb, a, extra=faces["blink" if 0.42 < p < 0.50 else "hi"])
    frames.append(transform(img, scale=1.0 + 0.02 * math.sin(2 * math.pi * p),
                            dy=-0.030 * abs(math.sin(2 * math.pi * p)),
                            squash=1.0 - 0.04 * math.sin(2 * math.pi * p)))
encode("anim_mascot_bounce", frames)

fld = shade_fields(sphere_mask(0.42), bevel=0.50, dome=0.02)
encode("anim_sphere_flow",
       [compose(*colorize(fld, tilt=0.5 * math.sin(2 * math.pi * i / N))) for i in range(N)])

fld = shade_fields(fa("f06d", cut_bottom=0.18, fill=0.90, bold=1))
frames = []
for i in range(N):
    p = 2 * math.pi * i / N
    rgb, a = colorize(fld, tilt=0.16 * math.sin(p) + 0.06 * math.sin(3 * p))
    frames.append(transform(compose(rgb, a), scale=1.0 + 0.04 * math.sin(p),
                            squash=1.0 + 0.05 * math.sin(p + 1.0), dy=-0.01 * math.sin(p)))
encode("anim_fire", frames)

fld = shade_fields(fa("f004", fill=0.84))
frames = []
for i in range(N):
    p = i / N
    beat = (1.0 + 0.10 * math.exp(-((p % 0.5) * 12) ** 2)
            + 0.06 * math.exp(-(((p % 0.5) - 0.12) * 10) ** 2))
    rgb, a = colorize(fld, tilt=0.08 * math.sin(2 * math.pi * p), ramp=RAMP_WARM)
    frames.append(transform(compose(rgb, a), scale=beat))
encode("anim_heart_beat", frames)

fld = shade_fields(fa("f061", fill=0.86))
frames = []
for i in range(N):
    sl = math.sin(2 * math.pi * i / N)
    frames.append(transform(compose(*colorize(fld, tilt=0.14 * sl)), dx=0.05 * sl))
encode("anim_arrow_next", frames)

shutil.rmtree(TMP, ignore_errors=True)
print("512x512 статичные PNG: см. stickers_512_static/")
