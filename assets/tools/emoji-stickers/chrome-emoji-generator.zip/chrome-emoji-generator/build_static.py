"""Сборка статичного набора кастом-эмодзи «ХРОМ» для Telegram."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from chrome_engine import *
from PIL import Image, ImageDraw

MONO = os.environ.get("CHROME_MONO") == "1"
if MONO:
    import chrome_engine as _ce
    _ce.RIM = (0xC8, 0xD2, 0xDA)          # нейтральный контровой вместо оранжевого
    RAMP = RAMP_GREEN = RAMP_WARM = RAMP_MONO
LOVE = (0x2A, 0x31, 0x37, 255) if MONO else (0xFF, 0x5A, 0x3C, 255)

OUTDIR = os.environ.get("CHROME_OUTDIR",
                       os.path.join(os.path.dirname(os.path.abspath(__file__)), "emoji"))
os.makedirs(OUTDIR, exist_ok=True)


def fa(code, **kw):
    return glyph_mask(chr(int(code, 16)), **kw)


# ---------- кастомные формы ----------
def drop_mask(fatness=0.355, apex=0.15):
    def d(dr, N):
        cx, cy, r = 0.5 * N, 0.63 * N, fatness * N
        ax, ay = 0.5 * N, apex * N
        dist = cy - ay
        alpha = math.asin(min(1, r / dist))
        pts = [(ax, ay)]
        # правая касательная -> обход круга снизу -> левая касательная
        start = -math.pi / 2 + alpha
        for i in range(121):
            a = start + i * (2 * math.pi - 2 * alpha) / 120
            pts.append((cx + r * math.sin(a + math.pi / 2) * 0 + r * math.cos(a - math.pi / 2),
                        cy + r * math.sin(a - math.pi / 2)))
        dr.polygon(pts, fill=255)
        dr.ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    return mask_from_draw(d)


def sphere_mask(r=0.40):
    return mask_from_draw(lambda dr, N: dr.ellipse(
        [(0.5 - r) * N, (0.5 - r) * N, (0.5 + r) * N, (0.5 + r) * N], fill=255))


def ring_mask(r=0.42, w=0.13):
    def d(dr, N):
        dr.ellipse([(0.5 - r) * N, (0.5 - r) * N, (0.5 + r) * N, (0.5 + r) * N], fill=255)
        i = r - w
        dr.ellipse([(0.5 - i) * N, (0.5 - i) * N, (0.5 + i) * N, (0.5 + i) * N], fill=0)
    return mask_from_draw(d)


def face_layer(kind="hi"):
    """глаза/рот поверх хрома"""
    ss = 2
    im = Image.new("RGBA", (S * ss, S * ss), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    N = S * ss
    DARK = (0x18, 0x20, 0x1C, 255)
    ex, ey, er = 0.372, 0.625, 0.072
    for sgn in (-1, 1):
        cx = (0.5 + sgn * (0.5 - ex)) * N
        cy = ey * N
        if kind == "wow":
            d.ellipse([cx - er * N, cy - er * 1.25 * N, cx + er * N, cy + er * 1.25 * N], fill=DARK)
        elif kind in ("think", "blink"):
            d.line([cx - er * N, cy, cx + er * N, cy], fill=DARK, width=int(0.030 * N))
        elif kind == "love":
            for k in (-1, 1):
                d.ellipse([cx - er * N + k * er * .5 * N, cy - er * N,
                           cx + k * er * .5 * N, cy], fill=LOVE)
            d.polygon([(cx - er * N, cy - er * .3 * N), (cx + er * N, cy - er * .3 * N),
                       (cx, cy + er * 1.1 * N)], fill=LOVE)
        else:
            d.ellipse([cx - er * N, cy - er * N, cx + er * N, cy + er * N], fill=DARK)
            d.ellipse([cx + er * .15 * N, cy - er * .75 * N,
                       cx + er * .70 * N, cy - er * .20 * N], fill=(255, 255, 255, 235))
    # рот
    mw, my = 0.088, 0.775
    if kind == "wow":
        d.ellipse([(0.5 - mw * .55) * N, (my - 0.055) * N,
                   (0.5 + mw * .55) * N, (my + 0.055) * N], fill=DARK)
    elif kind == "think":
        d.line([(0.5 - mw * .7) * N, my * N, (0.5 + mw * .2) * N, my * N],
               fill=DARK, width=int(0.028 * N))
    else:
        d.arc([(0.5 - mw) * N, (my - 0.075) * N, (0.5 + mw) * N, (my + 0.055) * N],
              15, 165, fill=DARK, width=int(0.030 * N))
    return im.resize((S, S), Image.LANCZOS)


# ---------- набор ----------
SET = []


def add(name, mask, ru, group, **kw):
    kw.setdefault("ramp", RAMP)          # в ч/б режиме RAMP == RAMP_MONO
    rgb, a = chrome_shade(mask, **{k: v for k, v in kw.items() if k != "extra"})
    img = compose(rgb, a, extra=kw.get("extra"))
    finish(img, name, OUTDIR)
    SET.append((name, ru, group))


def build_all():
    G = "Реакции"
    add("react_fire", fa("f06d", cut_bottom=0.18, fill=0.90, bold=1), "огонь / жиза", G)
    add("react_heart", fa("f004", fill=0.84), "люблю", G, ramp=RAMP_WARM)
    add("react_like", fa("f164", fill=0.84), "плюсую", G)
    add("react_eyes", fa("f06e", fill=0.90, bold=2), "слежу", G)
    add("react_star", fa("f005", fill=0.90), "в избранное", G, ramp=RAMP_GREEN)
    add("react_bolt", fa("f0e7", fill=0.82), "мощно", G, ramp=RAMP_WARM)
    add("react_smile", fa("f118", fill=0.90, bold=2), "смешно", G, ramp=RAMP_GREEN)
    add("react_gem", fa("f219", fill=0.86, bold=2), "ценно", G)

    G = "Навигация"
    add("nav_arrow_right", fa("f061", fill=0.86), "далее →", G)
    add("nav_arrow_down", fa("f061", fill=0.86, rot=-90), "листай ↓", G)
    add("nav_check", fa("f00c", fill=0.86), "готово", G, ramp=RAMP_GREEN)
    add("nav_plus", fa("f067", fill=0.80), "добавить", G)
    add("nav_alert", fa("f12a", fill=0.72), "важно", G, ramp=RAMP_WARM)
    add("nav_bullet", sphere_mask(0.26), "буллет", G)
    add("nav_play", fa("f04b", fill=0.78), "смотреть", G)
    add("nav_clock", fa("f017", fill=0.88, bold=1), "в записи", G)

    G = "Рубрики"
    add("rub_idea", fa("f0eb", fill=0.86, bold=1), "идея", G, ramp=RAMP_WARM)
    add("rub_tool", fa("f0ad", fill=0.86), "инструмент", G)
    add("rub_case", fa("f07b", fill=0.84), "кейс", G, ramp=RAMP_GREEN)
    add("rub_book", fa("f02d", fill=0.86, bold=1), "разбор", G)
    add("rub_rocket", fa("f135", fill=0.86), "запуск", G, ramp=RAMP_WARM)
    add("rub_quote", fa("f10d", fill=0.72), "цитата", G)
    add("rub_magic", fa("f0d0", fill=0.88, bold=1), "магия / ИИ", G, ramp=RAMP_GREEN)

    G = "Айдентика"
    add("id_mono_x", glyph_mask("X", POPPINS, fill=0.78), "монограмма Х", G)
    add("id_drop", drop_mask(), "хром-капля", G)
    add("id_sphere", sphere_mask(0.42), "хром-шар", G, dome=0.02, bevel=0.50)
    add("id_ring", ring_mask(), "хром-кольцо", G, bevel=0.10, dome=0.05)

    G = "Маскот «Хромик»"
    for kind, ru in [("hi", "Хромик привет"), ("wow", "Хромик в шоке"),
                     ("love", "Хромик влюблён"), ("think", "Хромик думает")]:
        add(f"mascot_{kind}", drop_mask(), ru, G, extra=face_layer(kind))

    # ---------- превью ----------
    import json
    json.dump([{"file": n + ".png", "name": r, "group": g} for n, r, g in SET],
              open(os.path.join(OUTDIR, "index.json"), "w"), ensure_ascii=False, indent=1)
    print(f"готово: {len(SET)} эмодзи")


if os.environ.get("CHROME_NOBUILD") != "1":
    build_all()
