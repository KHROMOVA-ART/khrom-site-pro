"""
Плоский цветной набор «ХРОМ FLAT».
Никакого объёма: сплошная заливка фирменным цветом + жёсткая смещённая тень
того же семейства. Цвет назначен по смыслу, а не по группе.
"""
import os, sys, json
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
os.environ["CHROME_NOBUILD"] = "1"          # импортируем только формы

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
import chrome_engine as ce
from build_static import drop_mask, sphere_mask, ring_mask, fa
from chrome_engine import glyph_mask, POPPINS, S, OUT

SIZE = int(os.environ.get("FLAT_SIZE", "100"))
OUTDIR = os.environ.get("FLAT_OUTDIR", f"{BASE}/emoji_flat")
os.makedirs(OUTDIR, exist_ok=True)

# ---------- фирменные цвета в плоском исполнении ----------
GREEN = (0x5C, 0xC2, 0x3E)
GREEN_D = (0x2C, 0x74, 0x22)
ORANGE = (0xFF, 0x7A, 0x18)
ORANGE_D = (0xB0, 0x47, 0x05)
PEACH = (0xFF, 0xC0, 0x95)
PEACH_D = (0xD1, 0x84, 0x52)
INK = (0x23, 0x2A, 0x2E)
CREAM = (0xFF, 0xF4, 0xE8)

PAIRS = {"green": (GREEN, GREEN_D), "orange": (ORANGE, ORANGE_D),
         "peach": (PEACH, PEACH_D), "ink": (INK, (0x0E, 0x12, 0x14))}


def flat(mask, key, shadow=0.055, extra=None):
    """сплошная заливка + жёсткая тень со смещением вниз-вправо"""
    main, dark = PAIRS[key]
    a = Image.fromarray((np.clip(mask, 0, 1) * 255).astype(np.uint8), "L")
    canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    sh = Image.new("RGBA", (S, S), dark + (0,))
    sh.putalpha(a)
    off = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    o = int(S * shadow)
    off.paste(sh, (o, o))
    canvas = Image.alpha_composite(canvas, off)

    top = Image.new("RGBA", (S, S), main + (0,))
    top.putalpha(a)
    canvas = Image.alpha_composite(canvas, top)
    if extra is not None:
        canvas = Image.alpha_composite(canvas, extra)
    return canvas.resize((SIZE, SIZE), Image.LANCZOS)


def flat_face(kind="hi"):
    ss = 2
    im = Image.new("RGBA", (S * ss, S * ss), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    N = S * ss
    ex, ey, er = 0.372, 0.615, 0.074
    for sgn in (-1, 1):
        cx, cy = (0.5 + sgn * (0.5 - ex)) * N, ey * N
        if kind == "wow":
            d.ellipse([cx - er * N, cy - er * 1.3 * N, cx + er * N, cy + er * 1.3 * N], fill=INK)
        elif kind == "think":
            d.line([cx - er * N, cy, cx + er * N, cy], fill=INK, width=int(0.032 * N))
        elif kind == "love":
            for k in (-1, 1):
                d.ellipse([cx - er * N + k * er * .5 * N, cy - er * N,
                           cx + k * er * .5 * N, cy], fill=ORANGE)
            d.polygon([(cx - er * N, cy - er * .3 * N), (cx + er * N, cy - er * .3 * N),
                       (cx, cy + er * 1.1 * N)], fill=ORANGE)
        else:
            d.ellipse([cx - er * N, cy - er * N, cx + er * N, cy + er * N], fill=INK)
    mw, my = 0.090, 0.775
    if kind == "wow":
        d.ellipse([(0.5 - mw * .55) * N, (my - 0.058) * N,
                   (0.5 + mw * .55) * N, (my + 0.058) * N], fill=INK)
    elif kind == "think":
        d.line([(0.5 - mw * .7) * N, my * N, (0.5 + mw * .2) * N, my * N],
               fill=INK, width=int(0.030 * N))
    else:
        d.arc([(0.5 - mw) * N, (my - 0.078) * N, (0.5 + mw) * N, (my + 0.058) * N],
              15, 165, fill=INK, width=int(0.032 * N))
    return im.resize((S, S), Image.LANCZOS)


SET = []


def add(name, mask, key, ru, group, **kw):
    flat(mask, key, **kw).save(f"{OUTDIR}/{name}.png")
    SET.append({"file": name + ".png", "name": ru, "group": group})


# ---------- цвет по смыслу ----------
# оранжевый — энергия и эмоция · зелёный — рост, действие, «да» · персик — нейтральное
G = "Реакции"
add("react_fire", fa("f06d", cut_bottom=0.18, fill=0.90, bold=1), "orange", "огонь / жиза", G)
add("react_heart", fa("f004", fill=0.84), "orange", "люблю", G)
add("react_like", fa("f164", fill=0.84), "green", "плюсую", G)
add("react_eyes", fa("f06e", fill=0.90, bold=2), "peach", "слежу", G)
add("react_star", fa("f005", fill=0.90), "green", "в избранное", G)
add("react_bolt", fa("f0e7", fill=0.82), "orange", "мощно", G)
add("react_smile", fa("f118", fill=0.90, bold=2), "green", "смешно", G)
add("react_gem", fa("f219", fill=0.86, bold=2), "peach", "ценно", G)

G = "Навигация"
add("nav_arrow_right", fa("f061", fill=0.86), "green", "далее →", G)
add("nav_arrow_down", fa("f061", fill=0.86, rot=-90), "green", "листай ↓", G)
add("nav_check", fa("f00c", fill=0.86), "green", "готово", G)
add("nav_plus", fa("f067", fill=0.80), "peach", "добавить", G)
add("nav_alert", fa("f12a", fill=0.72), "orange", "важно", G)
add("nav_bullet", sphere_mask(0.26), "peach", "буллет", G)
add("nav_play", fa("f04b", fill=0.78), "orange", "смотреть", G)
add("nav_clock", fa("f017", fill=0.88, bold=1), "peach", "в записи", G)

G = "Рубрики"
add("rub_idea", fa("f0eb", fill=0.86, bold=1), "orange", "идея", G)
add("rub_tool", fa("f0ad", fill=0.86), "peach", "инструмент", G)
add("rub_case", fa("f07b", fill=0.84), "green", "кейс", G)
add("rub_book", fa("f02d", fill=0.86, bold=1), "peach", "разбор", G)
add("rub_rocket", fa("f135", fill=0.86), "orange", "запуск", G)
add("rub_quote", fa("f10d", fill=0.72), "green", "цитата", G)
add("rub_magic", fa("f0d0", fill=0.88, bold=1), "green", "магия / ИИ", G)

G = "Айдентика"
add("id_mono_x", glyph_mask("X", POPPINS, fill=0.78), "orange", "монограмма Х", G)
add("id_drop", drop_mask(), "green", "капля", G)
add("id_sphere", sphere_mask(0.42), "orange", "круг", G)
add("id_ring", ring_mask(), "peach", "кольцо", G)

G = "Маскот «Хромик»"
for kind, ru in [("hi", "Хромик привет"), ("wow", "Хромик в шоке"),
                 ("love", "Хромик влюблён"), ("think", "Хромик думает")]:
    add(f"mascot_{kind}", drop_mask(), "peach", ru, G, extra=flat_face(kind))

json.dump(SET, open(f"{OUTDIR}/index.json", "w"), ensure_ascii=False, indent=1)
print(f"плоский набор: {len(SET)} шт · {SIZE}x{SIZE} · {OUTDIR}")
