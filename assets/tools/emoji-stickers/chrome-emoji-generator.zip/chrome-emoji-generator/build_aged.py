"""
Набор «ХРОМ · AGED» — Y2K-объекты в состаренной ч/б печати.
Без теней, без объёма из градиентов: только зерно, тон и шершавый контур.
"""
import os, sys, json, math
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
os.environ["CHROME_NOBUILD"] = "1"

import numpy as np
import chrome_engine as ce
ce.S = 600                                   # рабочее разрешение = aged_engine.R
import aged_engine as ae
from chrome_engine import glyph_mask, POPPINS, mask_from_draw
from build_static import drop_mask, sphere_mask
from PIL import Image, ImageDraw

R = ae.R
SIZE = int(os.environ.get("AGED_SIZE", "100"))
OUTDIR = os.environ.get("AGED_OUTDIR", f"{BASE}/emoji_aged")
os.makedirs(OUTDIR, exist_ok=True)


def fa(code, **kw):
    return glyph_mask(chr(int(code, 16)), **kw)


def draw(fn, ss=2):
    return mask_from_draw(fn, ss=ss)


def blob(fn, angle=0.0, ss=2):
    """нарисовать во временный слой и повернуть"""
    im = Image.new("L", (R * ss, R * ss), 0)
    fn(ImageDraw.Draw(im), R * ss)
    if angle:
        im = im.rotate(angle, resample=Image.BICUBIC, center=(R * ss / 2, R * ss / 2))
    return np.array(im.resize((R, R), Image.LANCZOS), np.float32) / 255.0


def union(*ms):
    out = ms[0]
    for m in ms[1:]:
        out = np.maximum(out, m)
    return out


# ---------------- кастомные формы ----------------
def sparkle(rad=0.44, cx=0.5, cy=0.5, sharp=0.32):
    def d(dr, N):
        pts = []
        for i in range(361):
            a = math.radians(i)
            r = rad * (1 - 0.88 * abs(math.sin(2 * a)) ** sharp) * N
            pts.append((cx * N + r * math.cos(a), cy * N + r * math.sin(a)))
        dr.polygon(pts, fill=255)
    return draw(d)


def sparkle_trio():
    return union(sparkle(0.30, 0.36, 0.38), sparkle(0.19, 0.70, 0.62),
                 sparkle(0.115, 0.58, 0.25))


def saturn():
    ball = blob(lambda dr, N: dr.ellipse([0.235 * N, 0.215 * N, 0.765 * N, 0.745 * N], fill=255))

    def ring(dr, N):
        dr.ellipse([0.02 * N, 0.395 * N, 0.98 * N, 0.645 * N], fill=255)
        dr.ellipse([0.155 * N, 0.452 * N, 0.845 * N, 0.588 * N], fill=0)
    rng = blob(ring, angle=18)
    return union(ball, rng), ball


def eightball():
    ball = sphere_mask(0.42)

    def det(dr, N):
        c, r = 0.5 * N, 0.175 * N
        dr.ellipse([c - r, c - r, c + r, c + r], outline=255, width=int(0.016 * N))
    ring = draw(det)
    txt = glyph_mask("8", POPPINS, fill=0.20)
    return ball, np.clip(ring + txt, 0, 1)


def bow():
    def loop(dr, N):
        dr.ellipse([0.015 * N, 0.275 * N, 0.455 * N, 0.605 * N], fill=255)
    L = blob(loop, angle=-14)
    Rr = np.fliplr(L)

    def knot(dr, N):
        dr.ellipse([0.415 * N, 0.375 * N, 0.585 * N, 0.545 * N], fill=255)
    def tails(dr, N):
        dr.polygon([(0.44 * N, 0.51 * N), (0.22 * N, 0.93 * N), (0.45 * N, 0.87 * N),
                    (0.50 * N, 0.60 * N)], fill=255)
        dr.polygon([(0.56 * N, 0.51 * N), (0.78 * N, 0.93 * N), (0.55 * N, 0.87 * N),
                    (0.50 * N, 0.60 * N)], fill=255)
    return union(L, Rr, draw(knot), draw(tails))


def _bez(p0, p1, p2, n=60):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1])
            for t in [i / n for i in range(n + 1)]]


def cherry():
    def berries(dr, N):
        dr.ellipse([0.05 * N, 0.53 * N, 0.45 * N, 0.93 * N], fill=255)
        dr.ellipse([0.55 * N, 0.58 * N, 0.93 * N, 0.96 * N], fill=255)

    def stems(dr, N):
        w = int(0.046 * N)
        top = (0.50, 0.21)
        for ctrl, end in [((0.34, 0.38), (0.25, 0.61)), ((0.67, 0.43), (0.74, 0.66))]:
            pts = [(x * N, y * N) for x, y in _bez(top, ctrl, end)]
            dr.line(pts, fill=255, width=w, joint="curve")

    def leaf(dr, N):
        dr.polygon([(0.49 * N, 0.22 * N), (0.66 * N, 0.05 * N), (0.86 * N, 0.10 * N),
                    (0.65 * N, 0.24 * N)], fill=255)
    return union(draw(berries), draw(stems), draw(leaf))


def pushpin():
    def d(dr, N):
        dr.ellipse([0.26 * N, 0.06 * N, 0.74 * N, 0.24 * N], fill=255)      # шляпка
        dr.rectangle([0.38 * N, 0.14 * N, 0.62 * N, 0.50 * N], fill=255)    # ножка
        dr.ellipse([0.20 * N, 0.44 * N, 0.80 * N, 0.64 * N], fill=255)      # юбка
        dr.polygon([(0.47 * N, 0.60 * N), (0.53 * N, 0.60 * N),
                    (0.52 * N, 0.96 * N)], fill=255)                        # игла
    return draw(d)


def spiral():
    def d(dr, N):
        pts = []
        for i in range(0, 900):
            a = math.radians(i)
            r = (0.03 + 0.00047 * i) * N
            pts.append((0.5 * N + r * math.cos(a), 0.5 * N + r * math.sin(a)))
        dr.line(pts, fill=255, width=int(0.045 * N), joint="curve")
    return draw(d)


def halo():
    def d(dr, N):
        dr.ellipse([0.08 * N, 0.34 * N, 0.92 * N, 0.66 * N], fill=255)
        dr.ellipse([0.20 * N, 0.40 * N, 0.80 * N, 0.60 * N], fill=0)
    return blob(d, angle=14)


def wordmark():
    def d(dr, N):
        u = lambda v: v * N
        t  = 0.036 * N              # толщина штриха
        y0, h = 0.335 * N, 0.330 * N
        yb = y0 + h

        def bar(p, q, w=t):
            dr.line([p, q], fill=255, width=int(w), joint="curve")

        # --- Х ---
        x, w = u(0.045), u(0.150)
        bar((x, y0), (x + w, yb)); bar((x + w, y0), (x, yb))

        # --- Р ---
        x, w = u(0.215), u(0.135)
        bar((x, y0), (x, yb))
        box = [x, y0, x + 2 * w * 0.62, y0 + h * 0.54]
        dr.arc(box, -90, 90, fill=255, width=int(t))
        bar((x, y0 + t * .1), (x + w * 0.62, y0 + t * .1))
        bar((x, y0 + h * 0.54), (x + w * 0.62, y0 + h * 0.54))

        # --- О (линза с точкой) ---
        x, w = u(0.360), u(0.150)
        cy = y0 + h / 2
        def lens(k):
            pts = []
            for i in range(0, 361):
                a = math.radians(i)
                pts.append((x + w / 2 + (w / 2 * k) * math.cos(a),
                            cy + (h / 2 * k) * abs(math.sin(a)) ** 1.35 * (1 if math.sin(a) >= 0 else -1)))
            return pts
        dr.polygon(lens(1.0), fill=255)
        dr.polygon(lens(0.60), fill=0)
        r = t * 0.46
        dr.ellipse([x + w / 2 - r, cy - r, x + w / 2 + r, cy + r], fill=255)

        # --- М ---
        x, w = u(0.530), u(0.175)
        dr.line([(x, yb), (x, y0), (x + w / 2, y0 + h * 0.62), (x + w, y0), (x + w, yb)],
                fill=255, width=int(t), joint="curve")

        # --- три точки ---
        xd = u(0.757)
        for cy2, rr in [(y0 + h * 0.18, t * 0.62), (y0 + h * 0.50, t * 0.44),
                        (y0 + h * 0.78, t * 0.34)]:
            dr.ellipse([xd - rr, cy2 - rr, xd + rr, cy2 + rr], fill=255)

        # --- Ъ ---
        x, w = u(0.790), u(0.165)
        sx = x + w * 0.28
        bar((sx, y0), (sx, yb))
        bar((x, y0), (sx, y0))
        bw = (x + w) - sx
        box = [sx - bw, y0 + h * 0.40, x + w, yb]
        dr.arc(box, -90, 90, fill=255, width=int(t))
        bar((sx, y0 + h * 0.40), (sx + bw * 0.0 + (x + w - sx) * 0.02, y0 + h * 0.40))
        bar((sx, yb), (sx + (x + w - sx) * 0.02, yb))
    return mask_from_draw(d, ss=2)



def dot(r=0.20):
    return draw(lambda dr, N: dr.ellipse([(0.5 - r) * N, (0.5 - r) * N,
                                          (0.5 + r) * N, (0.5 + r) * N], fill=255))


def ring_dot(r=0.22, w=0.075):
    def d(dr, N):
        dr.ellipse([(0.5 - r) * N, (0.5 - r) * N, (0.5 + r) * N, (0.5 + r) * N], fill=255)
        i = r - w
        dr.ellipse([(0.5 - i) * N, (0.5 - i) * N, (0.5 + i) * N, (0.5 + i) * N], fill=0)
    return draw(d)


def rhomb(r=0.26):
    return draw(lambda dr, N: dr.polygon(
        [(0.5 * N, (0.5 - r) * N), ((0.5 + r) * N, 0.5 * N),
         (0.5 * N, (0.5 + r) * N), ((0.5 - r) * N, 0.5 * N)], fill=255))


def dash(w=0.36, h=0.055):
    return draw(lambda dr, N: dr.rounded_rectangle(
        [(0.5 - w) * N, (0.5 - h) * N, (0.5 + w) * N, (0.5 + h) * N],
        radius=h * N, fill=255))


def arrow_curve():
    """изогнутая стрелка — «вот сюда»"""
    def d(dr, N):
        t = int(0.075 * N)
        pts = [(x * N, y * N) for x, y in _bez((0.14, 0.80), (0.26, 0.30), (0.70, 0.34))]
        dr.line(pts, fill=255, width=t, joint="curve")
        dr.polygon([(0.86 * N, 0.36 * N), (0.60 * N, 0.20 * N), (0.62 * N, 0.52 * N)], fill=255)
    return draw(d)


# ---------------- набор ----------------
SET = []


def add(name, mask, ru, group, detail=None, **kw):
    ae.render(mask, detail=detail, seed=len(SET) * 7 + 3, out_size=SIZE, **kw) \
        .save(f"{OUTDIR}/{name}.png")
    SET.append({"file": name + ".png", "name": ru, "group": group})


G = "Звёзды и свет"
add("star", fa("f005", fill=0.86), "звезда", G)
add("sparkle", sparkle(), "спаркл", G)
add("sparkle_trio", sparkle_trio(), "блёстки", G)
add("burst", fa("f0a3", fill=0.86), "печать", G)
add("sun", fa("f185", fill=0.84), "солнце", G)
add("moon", fa("f186", fill=0.80), "луна", G)

G = "Космос"
sat, sat_ball = saturn()
add("saturn", sat, "сатурн", G)
add("globe", fa("f0ac", fill=0.86), "глобус", G)
add("rocket", fa("f135", fill=0.86), "ракета", G)

G = "Сердце и милое"
add("heart", fa("f004", fill=0.84), "сердце", G)
add("bow", bow(), "бант", G)
add("cherry", cherry(), "вишня", G)
add("eye", fa("f06e", fill=0.90, bold=1), "глаз", G)
add("smile", fa("f118", fill=0.88, bold=1), "смайл", G)

G = "Стихии"
add("fire", fa("f06d", cut_bottom=0.18, fill=0.88), "огонь", G)
add("bolt", fa("f0e7", fill=0.82), "молния", G)
add("cloud", fa("f0c2", fill=0.88), "облако", G)
add("snowflake", fa("f2dc", fill=0.86, bold=1), "снежинка", G)

G = "Вещи"
ball, ball_det = eightball()
add("eightball", ball, "8-ball", G, detail=ball_det)
add("camera", fa("f030", fill=0.86), "мыльница", G)
add("headphones", fa("f025", fill=0.86), "наушники", G)
add("music", fa("f001", fill=0.80), "трек", G)
add("film", fa("f008", fill=0.86), "плёнка", G)
add("gamepad", fa("f11b", fill=0.88), "джойстик", G)
add("key", fa("f084", fill=0.84), "ключ", G)
add("clock", fa("f017", fill=0.86, bold=1), "будильник", G)

G = "Мелочь Y2K"
add("pushpin", pushpin(), "кнопка", G)
add("spiral", spiral(), "спираль", G)
add("halo", halo(), "нимб", G)
add("diamond", fa("f219", fill=0.86, bold=1), "камень", G)

G = "Фирменное"
add("drop", drop_mask(), "капля", G)
add("mono_x", glyph_mask("X", POPPINS, fill=0.76), "монограмма Х", G)
add("wordmark_hrom", wordmark(), "ХРОМЪ", G,
    edge=0.024, density=0.95, outline_w=0.0065)

G = "Форматирование"
add("li_dot", dot(), "буллет", G, edge=0.10)
add("li_ring", ring_dot(), "буллет пустой", G, edge=0.045)
add("li_rhomb", rhomb(), "буллет ромб", G, edge=0.10)
add("li_dash", dash(), "тире", G, edge=0.035)
add("li_sparkle", sparkle(0.28), "буллет-спаркл", G, edge=0.07)
add("ar_right", fa("f061", fill=0.80), "стрелка →", G, edge=0.09)
add("ar_down", fa("f061", fill=0.80, rot=-90), "стрелка ↓", G, edge=0.09)
add("ar_diag", fa("f061", fill=0.80, rot=45), "стрелка ↗", G, edge=0.09)
add("ar_chevron", fa("f054", fill=0.66), "шеврон ›", G, edge=0.055)
add("ar_curve", arrow_curve(), "изогнутая стрелка", G, edge=0.055)

json.dump(SET, open(f"{OUTDIR}/index.json", "w"), ensure_ascii=False, indent=1)
print(f"состаренный набор: {len(SET)} шт · {SIZE}x{SIZE} · {OUTDIR}")
