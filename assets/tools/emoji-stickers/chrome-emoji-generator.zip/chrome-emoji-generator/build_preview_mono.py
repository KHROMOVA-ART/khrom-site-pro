"""Контактный лист ч/б набора."""
import json, os
from PIL import Image, ImageDraw, ImageFont

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = f"{BASE}/emoji_mono"
F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
items = json.load(open(f"{SRC}/index.json"))

groups = []
for it in items:
    if not groups or groups[-1][0] != it["group"]:
        groups.append((it["group"], []))
    groups[-1][1].append(it)

CELL, PAD, COLS, head = 128, 34, 8, 132
W = PAD * 2 + COLS * CELL
sheet = Image.new("RGB", (W, 2000), (23, 25, 28))
d = ImageDraw.Draw(sheet)
d.text((PAD, 42), "ХРОМ · MONO", font=ImageFont.truetype(FB, 42), fill=(238, 243, 246))
d.text((PAD + 330, 56), "чистый хром, без цвета",
       font=ImageFont.truetype(F, 20), fill=(140, 150, 158))
d.line([(PAD, 108), (W - PAD, 108)], fill=(52, 58, 62), width=2)

y = head
fg, fl = ImageFont.truetype(FB, 20), ImageFont.truetype(F, 14)
for gname, gitems in groups:
    d.text((PAD, y), gname.upper(), font=fg, fill=(0xC6, 0xD2, 0xDA))
    y += 42
    for i, it in enumerate(gitems):
        x = PAD + (i % COLS) * CELL
        yy = y + (i // COLS) * (CELL + 30)
        im = Image.open(f"{SRC}/{it['file']}").convert("RGBA")
        sheet.paste(im, (x + (CELL - 100) // 2, yy), im)
        w = d.textlength(it["name"], font=fl)
        d.text((x + (CELL - w) / 2, yy + 104), it["name"], font=fl, fill=(160, 168, 174))
    y += ((len(gitems) + COLS - 1) // COLS) * (CELL + 30) + 18

sheet.crop((0, 0, W, y + 10)).save(f"{BASE}/preview_mono.png")

lite = Image.new("RGB", (W, 190), (0xFF, 0xFF, 0xFF))
dl = ImageDraw.Draw(lite)
dl.text((PAD, 26), "проверка на белом", font=ImageFont.truetype(F, 18), fill=(110, 116, 120))
for i, n in enumerate(["react_fire", "react_heart", "nav_check", "rub_idea", "id_drop",
                       "mascot_hi", "id_sphere", "react_star"]):
    im = Image.open(f"{SRC}/{n}.png").convert("RGBA")
    lite.paste(im, (PAD + i * CELL + 14, 66), im)
lite.save(f"{BASE}/preview_mono_light.png")
print("ok")
