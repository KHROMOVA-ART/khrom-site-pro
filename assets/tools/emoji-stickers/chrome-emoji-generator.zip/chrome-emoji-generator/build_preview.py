"""Контактный лист набора «ХРОМ»."""
import json, os, glob, subprocess
from PIL import Image, ImageDraw, ImageFont

BASE = os.path.dirname(os.path.abspath(__file__))
F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
items = json.load(open(f"{BASE}/emoji/index.json"))

groups = []
for it in items:
    if not groups or groups[-1][0] != it["group"]:
        groups.append((it["group"], []))
    groups[-1][1].append(it)

# анимированные — превью первым кадром
os.makedirs("/tmp/anim_prev", exist_ok=True)
anims = []
for w in sorted(glob.glob(f"{BASE}/emoji_animated/*.webm")):
    n = os.path.basename(w)[:-5]
    p = f"/tmp/anim_prev/{n}.png"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-c:v", "libvpx-vp9",
                    "-i", w, "-frames:v", "1", p], check=True)
    anims.append({"file": p, "name": n.replace("anim_", "").replace("_", " "), "abs": True})
groups.append(("Анимированные (WEBM)", anims))

CELL, PAD, COLS = 128, 34, 8
W = PAD * 2 + COLS * CELL
head = 132
rows_total = sum((len(g[1]) + COLS - 1) // COLS for g in groups)
H = head + PAD + sum(52 + ((len(g[1]) + COLS - 1) // COLS) * (CELL + 30) + 18 for g in groups)

BG = (23, 25, 28)
sheet = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(sheet)
d.text((PAD, 42), "ХРОМ", font=ImageFont.truetype(FB, 46), fill=(240, 245, 240))
d.text((PAD + 205, 58), "набор кастом-эмодзи · личный бренд Хромова",
       font=ImageFont.truetype(F, 20), fill=(150, 160, 155))
d.line([(PAD, 108), (W - PAD, 108)], fill=(52, 58, 56), width=2)

y = head
fg = ImageFont.truetype(FB, 20)
fl = ImageFont.truetype(F, 14)
for gname, gitems in groups:
    d.text((PAD, y), gname.upper(), font=fg, fill=(0x8C, 0xD6, 0x6E))
    y += 42
    for i, it in enumerate(gitems):
        col, row = i % COLS, i // COLS
        x = PAD + col * CELL
        yy = y + row * (CELL + 30)
        path = it["file"] if it.get("abs") else f"{BASE}/emoji/{it['file']}"
        im = Image.open(path).convert("RGBA")
        sheet.paste(im, (x + (CELL - 100) // 2, yy), im)
        lbl = it["name"]
        w = d.textlength(lbl, font=fl)
        d.text((x + (CELL - w) / 2, yy + 104), lbl, font=fl, fill=(168, 176, 172))
    y += ((len(gitems) + COLS - 1) // COLS) * (CELL + 30) + 18

sheet = sheet.crop((0, 0, W, y + 10))
sheet.save(f"{BASE}/preview_dark.png")

# светлая тема — проверка читаемости
lite = Image.new("RGB", (W, 190), (0xF2, 0xF4, 0xF0))
dl = ImageDraw.Draw(lite)
dl.text((PAD, 26), "проверка на светлой теме", font=ImageFont.truetype(F, 18),
        fill=(90, 96, 92))
picks = ["react_fire", "react_heart", "nav_check", "rub_idea", "id_drop",
         "mascot_hi", "id_sphere", "react_star"]
for i, n in enumerate(picks):
    im = Image.open(f"{BASE}/emoji/{n}.png").convert("RGBA")
    lite.paste(im, (PAD + i * CELL + 14, 66), im)
lite.save(f"{BASE}/preview_light.png")
print("preview ok", W, H)
