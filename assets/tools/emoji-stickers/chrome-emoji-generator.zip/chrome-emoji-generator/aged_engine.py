"""
Состаренная печать: кремовая заливка + графитовый стипл-грейн + шершавый контур.
Без теней. Тон строится аэрографом (тёмная кромка + свет сверху-слева),
затем разбивается в точку — как в старой ризографии.
"""
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from chrome_engine import edt

R = 600                       # рабочее разрешение
CREAM = (0xF1, 0xEC, 0xE3)
INK = (0x22, 0x26, 0x28)

_BAYER = np.array([
    [0, 32, 8, 40, 2, 34, 10, 42], [48, 16, 56, 24, 50, 18, 58, 26],
    [12, 44, 4, 36, 14, 46, 6, 38], [60, 28, 52, 20, 62, 30, 54, 22],
    [3, 35, 11, 43, 1, 33, 9, 41], [51, 19, 59, 27, 49, 17, 57, 25],
    [15, 47, 7, 39, 13, 45, 5, 37], [63, 31, 55, 23, 61, 29, 53, 21]], np.float32) / 64.0


def _threshold_field(shape, seed=0, organic=0.55):
    rng = np.random.default_rng(seed)
    b = np.tile(_BAYER, (shape[0] // 8 + 1, shape[1] // 8 + 1))[:shape[0], :shape[1]]
    return np.clip(b * (1 - organic) + rng.random(shape).astype(np.float32) * organic, 0, 1)


def tone_field(mask, edge=0.34, light=(0.34, 0.22), power=1.5):
    """аэрографный тон: 0 — бумага, 1 — плотная краска"""
    binary = mask > 0.5
    d = edt(binary)
    t = np.clip(d / (edge * R), 0, 1)
    rim = (1 - t) ** power                                  # плотнее к краю
    yy, xx = np.mgrid[0:R, 0:R] / R
    lx, ly = light
    dist = np.sqrt((xx - lx) ** 2 + (yy - ly) ** 2) / 1.05  # свет сверху-слева
    grad = np.clip(dist * 1.15 - 0.10, 0, 1) ** 1.25
    v = np.clip(0.30 * grad + 0.92 * rim * (0.35 + 0.75 * grad), 0, 1)
    v = np.where(binary, v, 0)
    v = np.array(Image.fromarray((v * 255).astype(np.uint8))
                 .filter(ImageFilter.GaussianBlur(R / 160)), np.float32) / 255.0
    return v * mask


def rough_edge(mask, amount=0.0035, seed=1):
    """шершавая кромка — как плохо пропечатанный край"""
    rng = np.random.default_rng(seed)
    n = rng.normal(0, 1, (R // 6, R // 6)).astype(np.float32)
    n = np.array(Image.fromarray(((n - n.min()) / (np.ptp(n) + 1e-6) * 255).astype(np.uint8))
                 .resize((R, R), Image.BICUBIC), np.float32) / 255.0
    n = (n - 0.5) * 2
    m = np.clip(mask + n * amount * R * 0.06, 0, 1)
    return np.clip((m - 0.42) * 6, 0, 1)


def outline(mask, w=0.011, seed=2, gaps=0.18):
    """контур с пропусками"""
    a = Image.fromarray((mask * 255).astype(np.uint8), "L")
    k = max(3, int(R * w) | 1)
    grow = a.filter(ImageFilter.MaxFilter(k))
    ring = np.clip(np.array(grow, np.float32) - np.array(a, np.float32), 0, 255) / 255.0
    rng = np.random.default_rng(seed)
    n = rng.random((R // 5, R // 5)).astype(np.float32)
    n = np.array(Image.fromarray((n * 255).astype(np.uint8)).resize((R, R), Image.BICUBIC),
                 np.float32) / 255.0
    return ring * (n > gaps)


def render(mask, detail=None, seed=0, edge=0.34, light=(0.34, 0.22),
           density=1.0, out_size=100, outline_w=0.011):
    """собирает состаренную иконку в RGBA"""
    mask = np.clip(mask, 0, 1)
    m = rough_edge(mask, seed=seed + 11)

    v = tone_field(m, edge=edge, light=light) * density
    thr = _threshold_field((R, R), seed=seed)
    dots = (v > thr).astype(np.float32) * m                 # стипл

    ink = np.clip(dots + outline(m, w=outline_w, seed=seed + 3), 0, 1)
    if detail is not None:
        dv = np.clip(np.asarray(detail, np.float32), 0, 1)
        ink = np.clip(ink + dv * (thr < 0.94), 0, 1)         # детали тоже с крупицей

    alpha = np.clip(m + ink, 0, 1)
    rgb = (np.array(CREAM, np.float32)[None, None, :] * (1 - ink)[..., None]
           + np.array(INK, np.float32)[None, None, :] * ink[..., None])

    img = Image.fromarray(np.dstack([rgb, alpha * 255]).astype(np.uint8), "RGBA")
    return img.resize((out_size, out_size), Image.LANCZOS)
