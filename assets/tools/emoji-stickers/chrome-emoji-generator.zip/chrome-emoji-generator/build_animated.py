"""Анимированные кастом-эмодзи «ХРОМ» -> WEBM (VP9 + alpha) под Telegram."""
import sys, os, math, subprocess, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from chrome_engine import *
from build_static import drop_mask, sphere_mask, face_layer, fa
from PIL import Image

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "emoji_animated")
TMP = "/tmp/chrome_frames"
os.makedirs(OUT, exist_ok=True)

FPS, DUR = 30, 2.0
N = int(FPS * DUR)


def transform(img, scale=1.0, dy=0.0, dx=0.0, squash=1.0):
    w = max(1, int(S * scale))
    h = max(1, int(S * scale * squash))
    r = img.resize((w, h), Image.LANCZOS)
    c = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    c.paste(r, (int((S - w) / 2 + dx * S), int((S - h) / 2 + dy * S)))
    return c


def encode(name, frames):
    if os.path.exists(TMP):
        shutil.rmtree(TMP)
    os.makedirs(TMP)
    for i, f in enumerate(frames):
        f.resize((OUT_SIZE, OUT_SIZE), Image.LANCZOS).save(f"{TMP}/f{i:03d}.png")
    dst = f"{OUT}/{name}.webm"
    subprocess.run([
        "ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS),
        "-i", f"{TMP}/f%03d.png", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
        "-b:v", "0", "-crf", "34", "-an", "-auto-alt-ref", "0",
        "-metadata:s:v:0", "alpha_mode=1", dst], check=True)
    kb = os.path.getsize(dst) / 1024
    print(f"{name}.webm  {kb:.1f} KB  {len(frames)} кадров")
    return kb


OUT_SIZE = 100

# ---------- 1. Хромик моргает и подпрыгивает ----------
dm = drop_mask()
fld = shade_fields(dm)
faces = {k: face_layer(k) for k in ("hi", "blink")}
frames = []
for i in range(N):
    p = i / N
    rgb, a = colorize(fld, tilt=0.10 * math.sin(2 * math.pi * p))
    blink = 0.42 < p < 0.50                  # моргание раз за цикл
    img = compose(rgb, a, extra=faces["blink" if blink else "hi"])
    bounce = -0.030 * abs(math.sin(2 * math.pi * p))
    frames.append(transform(img, scale=1.0 + 0.02 * math.sin(2 * math.pi * p),
                            dy=bounce, squash=1.0 - 0.04 * math.sin(2 * math.pi * p)))
encode("anim_mascot_bounce", frames)

# ---------- 2. Жидкий хром-шар ----------
fld = shade_fields(sphere_mask(0.42), bevel=0.50, dome=0.02)
frames = [compose(*colorize(fld, tilt=0.5 * math.sin(2 * math.pi * i / N))) for i in range(N)]
encode("anim_sphere_flow", frames)

# ---------- 3. Огонь ----------
fld = shade_fields(fa("f06d", cut_bottom=0.18, fill=0.90, bold=1))
frames = []
for i in range(N):
    p = 2 * math.pi * i / N
    rgb, a = colorize(fld, tilt=0.16 * math.sin(p) + 0.06 * math.sin(3 * p))
    frames.append(transform(compose(rgb, a), scale=1.0 + 0.04 * math.sin(p),
                            squash=1.0 + 0.05 * math.sin(p + 1.0), dy=-0.01 * math.sin(p)))
encode("anim_fire", frames)

# ---------- 4. Сердце бьётся ----------
fld = shade_fields(fa("f004", fill=0.84))
frames = []
for i in range(N):
    p = i / N
    beat = 1.0 + 0.10 * math.exp(-((p % 0.5) * 12) ** 2) + 0.06 * math.exp(-(((p % 0.5) - 0.12) * 10) ** 2)
    rgb, a = colorize(fld, tilt=0.08 * math.sin(2 * math.pi * p), ramp=RAMP_WARM)
    frames.append(transform(compose(rgb, a), scale=beat))
encode("anim_heart_beat", frames)

# ---------- 5. Стрелка «далее» ----------
fld = shade_fields(fa("f061", fill=0.86))
frames = []
for i in range(N):
    p = i / N
    sl = math.sin(2 * math.pi * p)
    rgb, a = colorize(fld, tilt=0.14 * sl)
    frames.append(transform(compose(rgb, a), dx=0.05 * sl))
encode("anim_arrow_next", frames)

shutil.rmtree(TMP, ignore_errors=True)
print("готово")
