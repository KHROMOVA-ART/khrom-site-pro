"""
Chrome-emoji engine — личный бренд «Хромова».
Палитра: травянисто-зелёный / персик / оранжевый + жидкий хром.
Рендерит маску -> EDT -> нормаль -> environment-map хром -> PNG 100x100 (RGBA).
"""
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

S = 400          # рабочее разрешение (даунсемплим до 100)
OUT = 100

FA = "/usr/share/fonts/truetype/font-awesome/fontawesome-webfont.ttf"
POPPINS = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"

# ---------- палитра бренда ----------
GREEN      = (0x5C, 0xC2, 0x3E)
GREEN_DEEP = (0x2E, 0x7D, 0x2A)
PEACH      = (0xFF, 0xC9, 0xA3)
ORANGE     = (0xFF, 0x7A, 0x18)
ORANGE_HOT = (0xFF, 0x9F, 0x3C)

# классический Y2K-хром, «небо» = зелёное, «земля» = персик/оранж
RAMP = [
    (0.00, (0xF2, 0xFF, 0xEC)),
    (0.10, (0xC7, 0xF2, 0xB2)),
    (0.20, GREEN),
    (0.30, (0xE8, 0xFF, 0xE0)),
    (0.42, (0xFF, 0xFF, 0xFF)),
    (0.478, (0xC2, 0xCE, 0xD6)),
    (0.50, (0x7E, 0x8C, 0x96)),
    (0.535, (0x3A, 0x42, 0x4A)),
    (0.58, (0x74, 0x4C, 0x2E)),
    (0.66, ORANGE),
    (0.78, ORANGE_HOT),
    (0.88, PEACH),
    (1.00, (0xFF, 0xF6, 0xEE)),
]

# альтернативные рампы (акцентные, для «цветных» иконок)
RAMP_GREEN = [
    (0.00, (0xF4, 0xFF, 0xEE)), (0.22, (0xA6, 0xE8, 0x86)), (0.42, (0xFF, 0xFF, 0xFF)),
    (0.50, (0x3E, 0x8C, 0x35)), (0.515, (0x1E, 0x4A, 0x1B)), (0.66, GREEN),
    (0.80, (0xB6, 0xEC, 0x9C)), (1.00, (0xF6, 0xFF, 0xF0)),
]
# чистый ч/б хром — без цветных отражений
RAMP_MONO = [
    (0.00, (0xFF, 0xFF, 0xFF)),
    (0.12, (0xE3, 0xE9, 0xEE)),
    (0.24, (0xB4, 0xBF, 0xC8)),
    (0.34, (0xFF, 0xFF, 0xFF)),
    (0.44, (0xDA, 0xE1, 0xE7)),
    (0.478, (0xA4, 0xB0, 0xB9)),
    (0.50, (0x68, 0x74, 0x7E)),
    (0.535, (0x24, 0x2B, 0x31)),
    (0.60, (0x47, 0x51, 0x59)),
    (0.72, (0x8C, 0x98, 0xA2)),
    (0.86, (0xCE, 0xD7, 0xDD)),
    (1.00, (0xFF, 0xFF, 0xFF)),
]

# цвет контрового блика на нижней кромке (в ч/б варианте переопределяется)
RIM = ORANGE

RAMP_WARM = [
    (0.00, (0xFF, 0xF6, 0xEE)), (0.20, PEACH), (0.42, (0xFF, 0xFF, 0xFF)),
    (0.50, (0xE0, 0x5A, 0x10)), (0.515, (0x6B, 0x24, 0x08)), (0.64, ORANGE),
    (0.80, ORANGE_HOT), (1.00, (0xFF, 0xEA, 0xD6)),
]


def ramp_lut(stops, n=1024):
    lut = np.zeros((n, 3), np.float32)
    xs = np.linspace(0, 1, n)
    pos = np.array([s[0] for s in stops], np.float32)
    cols = np.array([s[1] for s in stops], np.float32)
    for c in range(3):
        lut[:, c] = np.interp(xs, pos, cols[:, c])
    return lut


# ---------- exact euclidean distance transform (Felzenszwalb) ----------
def _edt1d(f):
    n = len(f)
    d = np.empty(n, np.float64)
    v = np.zeros(n, np.int64)
    z = np.empty(n + 1, np.float64)
    k = 0
    v[0] = 0
    z[0] = -np.inf
    z[1] = np.inf
    for q in range(1, n):
        s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2.0 * q - 2.0 * v[k])
        while s <= z[k]:
            k -= 1
            s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2.0 * q - 2.0 * v[k])
        k += 1
        v[k] = q
        z[k] = s
        z[k + 1] = np.inf
    k = 0
    for q in range(n):
        while z[k + 1] < q:
            k += 1
        d[q] = (q - v[k]) ** 2 + f[v[k]]
    return d


def edt(binary):
    """расстояние до ближайшего False-пикселя (в пикселях)"""
    INF = 1e12
    f = np.where(binary, INF, 0.0)
    for i in range(f.shape[0]):
        f[i] = _edt1d(f[i])
    f = f.T.copy()
    for i in range(f.shape[0]):
        f[i] = _edt1d(f[i])
    return np.sqrt(f.T)


# ---------- шейдинг ----------
def chrome_shade(mask, bevel=0.22, dome=0.25, tilt=0.0, ramp=RAMP,
                 spec=0.85, warp=0.0, seed=0, smooth=70):
    """mask: float 0..1 (S,S). Возвращает RGB float 0..255 и alpha."""
    a = mask
    binary = a > 0.5
    if binary.sum() == 0:
        return np.zeros((S, S, 3), np.float32), a

    d = edt(binary)
    R = bevel * S
    t = np.clip(d / R, 0, 1)
    h = np.sqrt(np.clip(1 - (1 - t) ** 2, 0, 1))          # фаска
    dm = np.clip(d / (d.max() + 1e-6), 0, 1)
    h = h * (1 - dome) + dome * np.sqrt(dm)               # общий «купол»
    h = np.where(binary, h, 0)

    hb = np.array(Image.fromarray((h * 255).astype(np.uint8))
                  .filter(ImageFilter.GaussianBlur(S / smooth)), np.float32) / 255.0

    gy, gx = np.gradient(hb * (R * 0.9))
    nz = np.ones_like(gx)
    nx, ny = -gx, -gy
    L = np.sqrt(nx * nx + ny * ny + nz * nz)
    nx, ny, nz = nx / L, ny / L, nz / L
    ny = -ny                                              # y вверх

    if warp:
        rng = np.random.default_rng(seed)
        yy, xx = np.mgrid[0:S, 0:S] / S
        ny = ny + warp * np.sin(xx * 11 + yy * 6 + rng.random() * 6)

    # environment map по вертикали нормали
    rng2 = np.random.default_rng(seed + 7)
    u = np.clip(0.5 - 0.60 * ny + 0.10 * nx + tilt
                + rng2.normal(0, 0.004, ny.shape), 0, 1)   # дизеринг против бандинга
    lut = ramp_lut(ramp)
    idx = (u * (len(lut) - 1)).astype(np.int32)
    rgb = lut[idx].astype(np.float32)

    # блик
    lx, ly, lz = -0.42, 0.72, 0.55
    ln = np.sqrt(lx * lx + ly * ly + lz * lz)
    lx, ly, lz = lx / ln, ly / ln, lz / ln
    ndl = np.clip(nx * lx + ny * ly + nz * lz, 0, 1)
    rgb += spec * 255 * (ndl ** 26)[..., None]

    # тёплый контровой на нижней кромке
    rim = np.clip(-ny, 0, 1) ** 3 * np.clip(1 - t, 0, 1)
    rgb += rim[..., None] * np.array(RIM, np.float32) * 0.35

    return np.clip(rgb, 0, 255), a


def shade_fields(mask, bevel=0.22, dome=0.25, smooth=70):
    """геометрия считается один раз — для анимации потом только перекрашиваем"""
    a = mask
    binary = a > 0.5
    d = edt(binary)
    R = bevel * S
    t = np.clip(d / R, 0, 1)
    h = np.sqrt(np.clip(1 - (1 - t) ** 2, 0, 1))
    dm = np.clip(d / (d.max() + 1e-6), 0, 1)
    h = np.where(binary, h * (1 - dome) + dome * np.sqrt(dm), 0)
    hb = np.array(Image.fromarray((h * 255).astype(np.uint8))
                  .filter(ImageFilter.GaussianBlur(S / smooth)), np.float32) / 255.0
    gy, gx = np.gradient(hb * (R * 0.9))
    nz = np.ones_like(gx)
    nx, ny = -gx, -gy
    L = np.sqrt(nx * nx + ny * ny + nz * nz)
    return nx / L, -ny / L, nz / L, t, a


def colorize(fields, tilt=0.0, ramp=RAMP, spec=0.85, seed=0):
    nx, ny, nz, t, a = fields
    rng2 = np.random.default_rng(seed + 7)
    u = np.clip(0.5 - 0.60 * ny + 0.10 * nx + tilt + rng2.normal(0, 0.004, ny.shape), 0, 1)
    lut = ramp_lut(ramp)
    rgb = lut[(u * (len(lut) - 1)).astype(np.int32)].astype(np.float32)
    lx, ly, lz = -0.42, 0.72, 0.55
    ln = np.sqrt(lx * lx + ly * ly + lz * lz)
    ndl = np.clip(nx * lx / ln + ny * ly / ln + nz * lz / ln, 0, 1)
    rgb += spec * 255 * (ndl ** 26)[..., None]
    rim = np.clip(-ny, 0, 1) ** 3 * np.clip(1 - t, 0, 1)
    rgb += rim[..., None] * np.array(RIM, np.float32) * 0.35
    return np.clip(rgb, 0, 255), a


def compose(rgb, alpha, outline=0.55, shadow=0.30, extra=None):
    """тонкий тёмный контур + мягкая тень (читается и на светлой, и на тёмной теме)"""
    base = np.dstack([rgb, alpha * 255]).astype(np.uint8)
    img = Image.fromarray(base, "RGBA")
    if extra is not None:
        img = Image.alpha_composite(img, extra)

    am = Image.fromarray((alpha * 255).astype(np.uint8), "L")
    canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    if outline > 0:
        grow = am.filter(ImageFilter.MaxFilter(7)).filter(ImageFilter.GaussianBlur(S / 200))
        oc = Image.new("RGBA", (S, S), (18, 24, 20, 255))
        oc.putalpha(grow.point(lambda v: int(v * outline)))
        canvas = Image.alpha_composite(canvas, oc)

    if shadow > 0:
        sh = am.filter(ImageFilter.GaussianBlur(S / 32))
        sc = Image.new("RGBA", (S, S), (26, 18, 10, 255))
        sc.putalpha(sh.point(lambda v: int(v * shadow)))
        off = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        off.paste(sc, (0, int(S / 45)))
        canvas = Image.alpha_composite(off, canvas)

    return Image.alpha_composite(canvas, img)


def finish(img, name, outdir):
    small = img.resize((OUT, OUT), Image.LANCZOS)
    p = f"{outdir}/{name}.png"
    small.save(p)
    return p


# ---------- источники масок ----------
def glyph_mask(char, font_path=FA, fill=0.86, dy=0.0, dx=0.0, rot=0.0, squash=1.0,
               cut_bottom=0.0, bold=0):
    size = int(S * 1.15)
    im = Image.new("L", (S * 2, S * 2), 0)
    d = ImageDraw.Draw(im)
    f = ImageFont.truetype(font_path, size)
    d.text((S, S), char, font=f, fill=255, anchor="mm")
    bb = im.getbbox()
    im = im.crop(bb)
    if cut_bottom:                       # убрать паразитные элементы глифа снизу
        w, h = im.size
        im = im.crop((0, 0, w, int(h * (1 - cut_bottom))))
        im = im.crop(im.getbbox())
    if rot:
        im = im.rotate(rot, expand=True, resample=Image.BICUBIC)
        im = im.crop(im.getbbox())
    w, h = im.size
    h = int(h * squash)
    k = (S * fill) / max(w, h)
    im = im.resize((max(1, int(w * k)), max(1, int(h * k))), Image.LANCZOS)
    out = Image.new("L", (S, S), 0)
    out.paste(im, (int((S - im.width) / 2 + dx * S), int((S - im.height) / 2 + dy * S)))
    if bold:                              # утолщение тонких глифов
        for _ in range(bold):
            out = out.filter(ImageFilter.MaxFilter(5))
        out = out.filter(ImageFilter.GaussianBlur(1.2))
    return np.array(out, np.float32) / 255.0


def mask_from_draw(fn, ss=2):
    im = Image.new("L", (S * ss, S * ss), 0)
    fn(ImageDraw.Draw(im), S * ss)
    im = im.resize((S, S), Image.LANCZOS)
    return np.array(im, np.float32) / 255.0
